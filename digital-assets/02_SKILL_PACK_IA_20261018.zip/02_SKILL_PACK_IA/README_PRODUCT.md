# Skill Pack IA FORJA + Ultra Instinct
Pega SKILL.md / SKILL_forja-ultra-instinct.md en tu IA.
Protocolo: canon, candidates, vigilante, anti-hype, dual judge.
