# LEGIÓN — Activos digitales listos para vender (2026-10-18)

## Problema de sesión
El montaje `/workspace/artifacts` falló con I/O error mid-build. Los packs se reconstruyeron en `/tmp/DIGITAL_ASSETS_FORJA`.

## 5 productos
1. **VOIDCROWN Playable Starter** ($19-29) — demo HTML + ruta al CANON 12.3
2. **Skill Pack IA FORJA+Ultra** ($29-49) — skills + prompts
3. **Solar Smash Risk Lab v1.3** ($9-15) — HTML jugable n-body
4. **Forja Engineering Kit** ($39-59) — scripts tar/listados/vigilante
5. **Bundle Legión Ω** ($79-99) — todo junto

## Scripts de producción
- `scripts/01_stamp_version.sh`
- `scripts/02_build_product_tarball.sh` (tar.gz + sha256, sin zip)
- `scripts/03_generate_store_listing.py`
- `scripts/04_price_matrix.sh`
- `scripts/05_make_all_products.sh`

## Cómo vender (3 pasos)
1. Sube `dist/*_v20261018.tar.gz` a Gumroad/itch.io
2. Copia el texto de `storefront/LISTING_*.md`
3. Adjunta LICENSE y el .sha256

## Canon completo
Aún en Drive: `VOIDCROWN_LEGION_41.0_GOLD/VOIDCROWN_CANON.html` — re-empaquetar en producto 01 cuando artifacts vuelva.
