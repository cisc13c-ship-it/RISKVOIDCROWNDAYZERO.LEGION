import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as ShaderMaterial, a as BufferAttribute, c as ClampToEdgeWrapping, d as LineBasicMaterial, f as LineLoop, g as SRGBColorSpace, h as RepeatWrapping, i as useThree, l as Color, m as Object3D, n as Canvas, o as BufferGeometry, p as MeshStandardMaterial, r as useFrame, s as CanvasTexture, t as OrbitControls, u as Line, v as SphereGeometry, y as Vector3 } from "../_libs/@react-three/drei+[...].mjs";
import { a as Pause, c as EyeOff, i as Play, n as Spline, o as Orbit, r as RotateCcw, s as Eye } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/solar-app-BWsEVO5x.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-[length:var(--motion-quick)] ease-[var(--ease-smooth-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] select-none", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:bg-accent/90",
			secondary: "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-muted hover:text-fg hover:bg-fg/5",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] hover:bg-fg/4"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs tracking-wide",
			icon: "size-11",
			"icon-sm": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Slider({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex h-11 w-full touch-none items-center select-none", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1 w-full grow overflow-hidden rounded-full bg-fg/12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-accent shadow-[0_0_0_4px_var(--color-bg)] ring-2 ring-transparent transition-[box-shadow] duration-[length:var(--motion-quick)] focus-visible:outline-none focus-visible:ring-ring" })]
	});
}
var DAYS_PER_REAL_SECOND = 365.25 / 24;
var BODIES = [
	{
		id: "sun",
		name: "Sol",
		kind: "star",
		subtitle: "Estrella enana G2V",
		radius: 4.6,
		distance: 0,
		au: 0,
		orbitYears: 0,
		dayLength: 25.05,
		tilt: 7.25,
		inclination: 0,
		moons: 0,
		diameterKm: 1392700,
		phase: 0,
		swatch: "#f0c27a",
		trail: "#f0c27a",
		texture: "sun",
		description: "El corazón gravitatorio del sistema. Una esfera de hidrógeno y helio que fusiona su núcleo a 15 millones de grados y arrastra a todos los planetas.",
		facts: [
			{
				label: "Tipo",
				value: "Enana amarilla"
			},
			{
				label: "Edad",
				value: "4.600 Ma"
			},
			{
				label: "Masa",
				value: "1 M☉"
			},
			{
				label: "Temperatura",
				value: "5.772 K"
			}
		]
	},
	{
		id: "mercury",
		name: "Mercurio",
		kind: "planet",
		subtitle: "Planeta terrestre",
		radius: .38,
		distance: 10.2,
		au: .39,
		orbitYears: .241,
		dayLength: 58.6,
		tilt: .03,
		inclination: 7,
		moons: 0,
		diameterKm: 4879,
		phase: .7,
		swatch: "#b9b3aa",
		trail: "#c9c2b8",
		texture: "rocky",
		description: "El más cercano al Sol y el más marcado por cráteres. Entre el día abrasador y la noche gélida hay más de 600 °C de diferencia.",
		facts: [
			{
				label: "Distancia",
				value: "0,39 UA"
			},
			{
				label: "Órbita",
				value: "88 días"
			},
			{
				label: "Día",
				value: "59 días"
			},
			{
				label: "Lunas",
				value: "Ninguna"
			}
		]
	},
	{
		id: "venus",
		name: "Venus",
		kind: "planet",
		subtitle: "Planeta terrestre",
		radius: .72,
		distance: 14.4,
		au: .72,
		orbitYears: .615,
		dayLength: -243,
		tilt: 177.4,
		inclination: 3.4,
		moons: 0,
		diameterKm: 12104,
		phase: 2.4,
		swatch: "#e4d0a8",
		trail: "#edd9b0",
		texture: "venus",
		description: "Gemelo de la Tierra en tamaño, cubierto por nubes de ácido sulfúrico. Gira al revés y un día suyo dura más que su año.",
		facts: [
			{
				label: "Distancia",
				value: "0,72 UA"
			},
			{
				label: "Órbita",
				value: "225 días"
			},
			{
				label: "Día",
				value: "243 días ↺"
			},
			{
				label: "Atmósfera",
				value: "CO₂ denso"
			}
		]
	},
	{
		id: "earth",
		name: "Tierra",
		kind: "planet",
		subtitle: "Planeta terrestre",
		radius: .78,
		distance: 19.2,
		au: 1,
		orbitYears: 1,
		dayLength: 1,
		tilt: 23.4,
		inclination: 0,
		moons: 1,
		diameterKm: 12756,
		phase: 4.1,
		swatch: "#6ea4d8",
		trail: "#8ec0ee",
		texture: "earth",
		hasClouds: true,
		hasMoon: true,
		description: "El único mundo conocido con vida. Océanos líquidos, una luna estable y un campo magnético que desvía el viento solar.",
		facts: [
			{
				label: "Distancia",
				value: "1 UA"
			},
			{
				label: "Órbita",
				value: "365,25 días"
			},
			{
				label: "Día",
				value: "23 h 56 min"
			},
			{
				label: "Lunas",
				value: "1 · Luna"
			}
		]
	},
	{
		id: "mars",
		name: "Marte",
		kind: "planet",
		subtitle: "Planeta terrestre",
		radius: .52,
		distance: 24.6,
		au: 1.52,
		orbitYears: 1.881,
		dayLength: 1.03,
		tilt: 25.2,
		inclination: 1.85,
		moons: 2,
		diameterKm: 6792,
		phase: 1.2,
		swatch: "#c56a48",
		trail: "#d98a68",
		texture: "mars",
		description: "El planeta rojo. Valles secos, casquetes polares de hielo y el volcán más alto del sistema solar, Olympus Mons.",
		facts: [
			{
				label: "Distancia",
				value: "1,52 UA"
			},
			{
				label: "Órbita",
				value: "687 días"
			},
			{
				label: "Día",
				value: "24 h 37 min"
			},
			{
				label: "Lunas",
				value: "2 · Fobos, Deimos"
			}
		]
	},
	{
		id: "jupiter",
		name: "Júpiter",
		kind: "planet",
		subtitle: "Gigante gaseoso",
		radius: 2.35,
		distance: 36.5,
		au: 5.2,
		orbitYears: 11.86,
		dayLength: .41,
		tilt: 3.1,
		inclination: 1.3,
		moons: 95,
		diameterKm: 142984,
		phase: 3.6,
		swatch: "#d4b48a",
		trail: "#e0c49a",
		texture: "gas",
		description: "El mayor de todos. Su Gran Mancha Roja es una tormenta más ancha que la Tierra, activa desde hace siglos.",
		facts: [
			{
				label: "Distancia",
				value: "5,20 UA"
			},
			{
				label: "Órbita",
				value: "11,9 años"
			},
			{
				label: "Día",
				value: "9 h 56 min"
			},
			{
				label: "Lunas",
				value: "95"
			}
		]
	},
	{
		id: "saturn",
		name: "Saturno",
		kind: "planet",
		subtitle: "Gigante gaseoso",
		radius: 2.02,
		distance: 50.5,
		au: 9.58,
		orbitYears: 29.46,
		dayLength: .45,
		tilt: 26.7,
		inclination: 2.49,
		moons: 146,
		diameterKm: 120536,
		phase: 5.5,
		swatch: "#e6d3a4",
		trail: "#f0dfb4",
		texture: "gas",
		hasRings: true,
		description: "Ligero como para flotar en agua, si existiera un océano tan grande. Sus anillos son hielo y polvo en órbita milimétrica.",
		facts: [
			{
				label: "Distancia",
				value: "9,58 UA"
			},
			{
				label: "Órbita",
				value: "29,5 años"
			},
			{
				label: "Día",
				value: "10 h 33 min"
			},
			{
				label: "Anillos",
				value: "Hasta 282.000 km"
			}
		]
	},
	{
		id: "uranus",
		name: "Urano",
		kind: "planet",
		subtitle: "Gigante de hielo",
		radius: 1.22,
		distance: 63.5,
		au: 19.2,
		orbitYears: 84.01,
		dayLength: -.72,
		tilt: 97.8,
		inclination: .77,
		moons: 28,
		diameterKm: 51118,
		phase: 2.2,
		swatch: "#9fd4d8",
		trail: "#b7e4e6",
		texture: "ice-giant",
		description: "Rueda de lado: su eje está tumbado casi 98°. Un mundo frío de hielos de agua, amoníaco y metano que tiñe la atmósfera de cian.",
		facts: [
			{
				label: "Distancia",
				value: "19,2 UA"
			},
			{
				label: "Órbita",
				value: "84 años"
			},
			{
				label: "Día",
				value: "17 h 14 min ↺"
			},
			{
				label: "Inclinación",
				value: "97,8°"
			}
		]
	},
	{
		id: "neptune",
		name: "Neptuno",
		kind: "planet",
		subtitle: "Gigante de hielo",
		radius: 1.18,
		distance: 76,
		au: 30.05,
		orbitYears: 164.8,
		dayLength: .67,
		tilt: 28.3,
		inclination: 1.77,
		moons: 16,
		diameterKm: 49528,
		phase: .9,
		swatch: "#4a7fd4",
		trail: "#6a99e4",
		texture: "ice-giant",
		description: "El más lejano. Vientos supersónicos y un azul profundo por el metano. Fue predicho con matemáticas antes de ser visto.",
		facts: [
			{
				label: "Distancia",
				value: "30,1 UA"
			},
			{
				label: "Órbita",
				value: "165 años"
			},
			{
				label: "Día",
				value: "16 h 6 min"
			},
			{
				label: "Lunas",
				value: "16 · Tritón"
			}
		]
	}
];
var PLANETS = BODIES.filter((b) => b.kind === "planet");
var SUN = BODIES[0];
var BODY_BY_ID = BODIES.reduce((acc, body) => {
	acc[body.id] = body;
	return acc;
}, {});
function formatSimTime(days) {
	const year = days / 365.25;
	const dayOfYear = Math.floor(days % 365.25) + 1;
	return {
		year: year.toFixed(2),
		day: String(dayOfYear)
	};
}
function speedFromSlider(t) {
	const min = .25;
	return min * Math.pow(50 / min, t);
}
function sliderFromSpeed(speed) {
	const min = .25;
	const max = 50;
	return Math.log(Math.min(max, Math.max(min, speed)) / min) / Math.log(max / min);
}
function formatSpeed(speed) {
	if (speed >= 10) return `${Math.round(speed)}×`;
	if (speed >= 1) return `${speed.toFixed(1)}×`;
	return `${speed.toFixed(2)}×`;
}
var bodyAnchors = /* @__PURE__ */ new Map();
var labelNodes = /* @__PURE__ */ new Map();
var simClock = { days: 0 };
var STORAGE_KEY = "orbita-sim-v1";
function load() {
	if (typeof window === "undefined") return {};
	try {
		const raw = window.localStorage.getItem(STORAGE_KEY);
		if (!raw) return {};
		const parsed = JSON.parse(raw);
		return parsed && typeof parsed === "object" ? parsed : {};
	} catch {
		return {};
	}
}
var persisted = load();
var useSim = create((set, get) => {
	const persist = () => {
		if (typeof window === "undefined") return;
		const { speed, showLabels, showOrbits, showTrails } = get();
		window.localStorage.setItem(STORAGE_KEY, JSON.stringify({
			speed,
			showLabels,
			showOrbits,
			showTrails
		}));
	};
	return {
		paused: false,
		speed: typeof persisted.speed === "number" ? persisted.speed : 1,
		selectedId: null,
		showLabels: persisted.showLabels ?? true,
		showOrbits: persisted.showOrbits ?? true,
		showTrails: persisted.showTrails ?? true,
		simDays: 0,
		focusNonce: 0,
		setPaused: (value) => set({ paused: value }),
		togglePaused: () => set({ paused: !get().paused }),
		setSpeed: (value) => {
			set({ speed: value });
			persist();
		},
		focus: (id) => set((state) => ({
			selectedId: id,
			focusNonce: state.focusNonce + 1
		})),
		clearFocus: () => {
			if (get().selectedId === null) return;
			set((state) => ({
				selectedId: null,
				focusNonce: state.focusNonce + 1
			}));
		},
		setShowLabels: (value) => {
			set({ showLabels: value });
			persist();
		},
		setShowOrbits: (value) => {
			set({ showOrbits: value });
			persist();
		},
		setShowTrails: (value) => {
			set({ showTrails: value });
			persist();
		},
		setSimDays: (value) => set({ simDays: value })
	};
});
function Overlay() {
	const paused = useSim((s) => s.paused);
	const speed = useSim((s) => s.speed);
	const selectedId = useSim((s) => s.selectedId);
	const showLabels = useSim((s) => s.showLabels);
	const showOrbits = useSim((s) => s.showOrbits);
	const showTrails = useSim((s) => s.showTrails);
	const simDays = useSim((s) => s.simDays);
	const selected = selectedId ? BODY_BY_ID[selectedId] : null;
	const time = formatSimTime(simDays);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			if (e.code === "Space") {
				e.preventDefault();
				useSim.getState().togglePaused();
			} else if (e.code === "Escape") useSim.getState().focus(null);
			else if (e.key === "[" || e.key === "-") useSim.getState().setSpeed(Math.max(.25, speed * .7));
			else if (e.key === "]" || e.key === "+" || e.key === "=") useSim.getState().setSpeed(Math.min(50, speed * 1.4));
			else if (e.key === "l" || e.key === "L") useSim.getState().setShowLabels(!useSim.getState().showLabels);
			else if (e.key === "o" || e.key === "O") useSim.getState().setShowOrbits(!useSim.getState().showOrbits);
			else if (e.key === "t" || e.key === "T") useSim.getState().setShowTrails(!useSim.getState().showTrails);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [speed]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10 text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vignette absolute inset-0" }),
			BODIES.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"data-body": body.id,
				"data-selected": selectedId === body.id ? "true" : "false",
				ref: (node) => {
					if (node) labelNodes.set(body.id, node);
					else labelNodes.delete(body.id);
				},
				className: "planet-label pointer-events-none absolute top-0 left-0",
				children: body.name
			}, body.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "pointer-events-none flex items-start justify-between gap-4 p-4 md:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-[16rem]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] tracking-[0.32em] text-muted uppercase",
							children: "Observatorio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl leading-none tracking-tight italic md:text-5xl",
							children: "Órbita"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-[14rem] text-sm leading-snug text-muted",
							children: "Arrastra para girar. Pulsa un mundo para acercarte."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto flex items-center gap-1 rounded-2xl bg-surface/80 p-1 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							pressed: showLabels,
							onPressed: () => useSim.getState().setShowLabels(!showLabels),
							label: showLabels ? "Ocultar etiquetas" : "Mostrar etiquetas",
							children: showLabels ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							pressed: showOrbits,
							onPressed: () => useSim.getState().setShowOrbits(!showOrbits),
							label: showOrbits ? "Ocultar órbitas" : "Mostrar órbitas",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orbit, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							pressed: showTrails,
							onPressed: () => useSim.getState().setShowTrails(!showTrails),
							label: showTrails ? "Ocultar estelas" : "Mostrar estelas",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spline, { className: "size-4" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute top-28 bottom-36 left-4 hidden w-52 flex-col md:flex lg:top-32 lg:bottom-32 lg:left-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "pointer-events-auto overflow-hidden rounded-2xl bg-surface/80 p-2 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-3 pt-2 pb-1 text-[11px] tracking-[0.22em] text-muted uppercase",
						children: "Cuerpos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col",
						children: BODIES.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => useSim.getState().focus(body.id),
							className: cn("flex h-11 w-full items-center gap-3 rounded-xl px-3 text-left text-sm transition-[background-color,color] duration-[length:var(--motion-quick)]", selectedId === body.id ? "bg-fg/8 text-fg" : "text-muted hover:bg-fg/5 hover:text-fg"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"data-body": body.id,
									className: "swatch size-2.5 shrink-0 rounded-full",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 truncate",
									children: body.name
								}),
								body.kind === "star" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] tracking-wider text-subtle uppercase",
									children: "estrella"
								}) : null
							]
						}) }, body.id))
					})]
				})
			}),
			selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "pointer-events-auto panel-enter absolute right-4 bottom-36 max-h-[min(52vh,28rem)] w-[min(calc(100%-2rem),20.5rem)] overflow-auto rounded-2xl bg-surface/80 p-4 shadow-[var(--shadow-border)] md:top-32 md:right-6 md:bottom-32 md:max-h-none md:w-80 md:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] tracking-[0.22em] text-muted uppercase",
							children: selected.subtitle
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display mt-1 text-3xl leading-none italic",
							children: selected.name
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"data-body": selected.id,
							className: "swatch mt-1 size-3 rounded-full",
							"aria-hidden": "true"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm leading-relaxed text-pretty text-muted",
						children: selected.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-5 grid grid-cols-2 gap-x-4 gap-y-3",
						children: selected.facts.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-[11px] tracking-[0.18em] text-subtle uppercase",
							children: fact.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-sm tabular-nums",
							children: fact.value
						})] }, fact.label))
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "pointer-events-none absolute inset-x-0 bottom-0 p-4 md:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-3 flex gap-2 overflow-x-auto pb-1 md:hidden",
					children: BODIES.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => useSim.getState().focus(body.id),
						className: cn("pointer-events-auto flex h-11 shrink-0 items-center gap-2 rounded-full px-3.5 text-sm shadow-[var(--shadow-border)]", selectedId === body.id ? "bg-accent text-accent-fg" : "bg-surface/85 text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"data-body": body.id,
							className: "swatch size-2 rounded-full",
							"aria-hidden": "true"
						}), body.name]
					}, body.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto mx-auto flex max-w-3xl flex-col gap-3 rounded-2xl bg-surface/85 p-2 shadow-[var(--shadow-border)] md:flex-row md:items-center md:gap-4 md:rounded-2xl md:p-2 md:pr-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								"aria-label": paused ? "Reanudar" : "Pausa",
								onClick: () => useSim.getState().togglePaused(),
								children: paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 translate-x-px" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								"aria-label": "Vista general",
								onClick: () => useSim.getState().focus(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden h-8 w-px bg-border md:block" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden px-2 md:block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] tracking-[0.2em] text-subtle uppercase",
									children: "Año"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium tabular-nums leading-tight",
									children: time.year
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-1 items-center gap-3 px-2 pb-1 md:pb-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "sim-speed",
								className: "shrink-0 text-[11px] tracking-[0.18em] text-muted uppercase",
								children: "Velocidad"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								id: "sim-speed",
								min: 0,
								max: 1,
								step: .01,
								value: [sliderFromSpeed(speed)],
								onValueChange: ([t]) => {
									if (typeof t === "number") useSim.getState().setSpeed(speedFromSlider(t));
								},
								"aria-label": "Velocidad de simulación"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-12 shrink-0 text-right text-sm tabular-nums",
								children: formatSpeed(speed)
							})
						]
					})]
				})]
			})
		]
	});
}
function Toggle({ pressed, onPressed, label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		variant: "ghost",
		size: "icon-sm",
		"aria-label": label,
		"aria-pressed": pressed,
		onClick: onPressed,
		className: cn(pressed ? "text-fg" : "text-subtle"),
		children
	});
}
function hash$1(ix, iy, iz) {
	const n = Math.sin(ix * 127.1 + iy * 311.7 + iz * 74.7) * 43758.5453;
	return n - Math.floor(n);
}
function noise3(x, y, z) {
	const ix = Math.floor(x);
	const iy = Math.floor(y);
	const iz = Math.floor(z);
	const fx = x - ix;
	const fy = y - iy;
	const fz = z - iz;
	const ux = fx * fx * (3 - 2 * fx);
	const uy = fy * fy * (3 - 2 * fy);
	const uz = fz * fz * (3 - 2 * fz);
	const n000 = hash$1(ix, iy, iz);
	const n100 = hash$1(ix + 1, iy, iz);
	const n010 = hash$1(ix, iy + 1, iz);
	const n110 = hash$1(ix + 1, iy + 1, iz);
	const n001 = hash$1(ix, iy, iz + 1);
	const n101 = hash$1(ix + 1, iy, iz + 1);
	const n011 = hash$1(ix, iy + 1, iz + 1);
	const n111 = hash$1(ix + 1, iy + 1, iz + 1);
	const nx00 = n000 * (1 - ux) + n100 * ux;
	const nx10 = n010 * (1 - ux) + n110 * ux;
	const nx01 = n001 * (1 - ux) + n101 * ux;
	const nx11 = n011 * (1 - ux) + n111 * ux;
	const nxy0 = nx00 * (1 - uy) + nx10 * uy;
	const nxy1 = nx01 * (1 - uy) + nx11 * uy;
	return nxy0 * (1 - uz) + nxy1 * uz;
}
function fbm(x, y, z, octaves = 4) {
	let value = 0;
	let amp = .5;
	let freq = 1;
	for (let i = 0; i < octaves; i++) {
		value += amp * noise3(x * freq, y * freq, z * freq);
		amp *= .5;
		freq *= 2;
	}
	return value;
}
function wrapNoise(lon, lat, scale, seed = 0) {
	return fbm(Math.cos(lon) * Math.cos(lat) * scale, Math.sin(lat) * scale, Math.sin(lon) * Math.cos(lat) * scale + seed * 17.2);
}
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function mix(a, b, t) {
	return [
		lerp(a[0], b[0], t),
		lerp(a[1], b[1], t),
		lerp(a[2], b[2], t)
	];
}
function toTexture(canvas) {
	const texture = new CanvasTexture(canvas);
	texture.colorSpace = SRGBColorSpace;
	texture.wrapS = RepeatWrapping;
	texture.wrapT = ClampToEdgeWrapping;
	texture.anisotropy = 8;
	texture.needsUpdate = true;
	return texture;
}
function makeCanvas(width, height) {
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) throw new Error("Canvas 2D unavailable");
	const image = ctx.createImageData(width, height);
	return {
		canvas,
		ctx,
		data: image.data,
		put: () => ctx.putImageData(image, 0, 0)
	};
}
function setPx(data, w, x, y, r, g, b, a = 255) {
	const i = (y * w + x) * 4;
	data[i] = r;
	data[i + 1] = g;
	data[i + 2] = b;
	data[i + 3] = a;
}
function paintRocky(data, w, h, base, dark, craterDensity) {
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const lon = x / w * Math.PI * 2;
		const lat = y / h * Math.PI - Math.PI / 2;
		const n = wrapNoise(lon, lat, 4.2, 1);
		const n2 = wrapNoise(lon, lat, 11, 4);
		let t = n * .7 + n2 * .3;
		const crater = wrapNoise(lon, lat, 18, 9);
		if (crater > craterDensity) t -= (crater - craterDensity) * 1.8;
		const c = mix(dark, base, Math.min(1, Math.max(0, t)));
		setPx(data, w, x, y, c[0], c[1], c[2]);
	}
}
function paintEarth(data, w, h) {
	const oceanDeep = [
		8,
		48,
		108
	];
	const ocean = [
		24,
		96,
		168
	];
	const land = [
		42,
		118,
		58
	];
	const desert = [
		168,
		148,
		86
	];
	const ice = [
		236,
		240,
		244
	];
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const lon = x / w * Math.PI * 2;
		const lat = y / h * Math.PI - Math.PI / 2;
		const n = wrapNoise(lon, lat, 2.6, 2);
		const ridges = wrapNoise(lon, lat, 7.5, 6);
		const polar = Math.pow(Math.abs(Math.sin(lat)), 6);
		let c;
		if (polar > .72 || polar > .45 && n > .46) c = mix(ocean, ice, Math.min(1, polar + .2));
		else if (n > .57) {
			const arid = wrapNoise(lon, lat + .4, 3.2, 8);
			c = mix(land, desert, Math.max(0, arid - .45) * 1.6);
			c = mix(c, [
				32,
				78,
				44
			], ridges * .25);
		} else c = mix(oceanDeep, ocean, n * 1.4);
		setPx(data, w, x, y, c[0], c[1], c[2]);
	}
}
function paintMars(data, w, h) {
	const rust = [
		168,
		72,
		42
	];
	const dark = [
		92,
		42,
		28
	];
	const dust = [
		196,
		118,
		72
	];
	const ice = [
		232,
		228,
		220
	];
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const lon = x / w * Math.PI * 2;
		const lat = y / h * Math.PI - Math.PI / 2;
		const n = wrapNoise(lon, lat, 3.4, 3);
		const polar = Math.pow(Math.abs(Math.sin(lat)), 8);
		let c = mix(dark, rust, n);
		c = mix(c, dust, wrapNoise(lon, lat, 8, 5) * .45);
		if (polar > .55) c = mix(c, ice, (polar - .55) * 3);
		setPx(data, w, x, y, c[0], c[1], c[2]);
	}
}
function paintVenus(data, w, h) {
	const pale = [
		228,
		206,
		158
	];
	const swirl = [
		196,
		168,
		118
	];
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const lon = x / w * Math.PI * 2 + y / h * 1.4;
		const lat = y / h * Math.PI - Math.PI / 2;
		const bands = .5 + .5 * Math.sin(lat * 10 + wrapNoise(lon, lat, 2, 1) * 4);
		const n = wrapNoise(lon, lat, 5, 2);
		const c = mix(pale, swirl, bands * .55 + n * .25);
		setPx(data, w, x, y, c[0], c[1], c[2]);
	}
}
function paintGas(data, w, h, a, b, c, storm) {
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const lon = x / w * Math.PI * 2;
		const lat = y / h * Math.PI - Math.PI / 2;
		const warp = wrapNoise(lon, lat, 2.2, 1) * 1.4;
		const bands = Math.sin(lat * 14 + warp * 3);
		const n = wrapNoise(lon * .4 + lat * 6, lat, 3.5, 4);
		let col = mix(a, b, .5 + .5 * bands);
		col = mix(col, c, n * .4);
		if (storm) {
			const dlon = lon - storm.lon;
			const dlat = lat - storm.lat;
			const d = Math.sqrt(dlon * dlon * .6 + dlat * dlat * 3.2);
			if (d < .28) col = mix(col, storm.color, 1 - d / .28);
		}
		setPx(data, w, x, y, col[0], col[1], col[2]);
	}
}
function paintIceGiant(data, w, h, base, deep) {
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const lon = x / w * Math.PI * 2;
		const lat = y / h * Math.PI - Math.PI / 2;
		const bands = .5 + .5 * Math.sin(lat * 6 + wrapNoise(lon, lat, 1.6, 2) * 2);
		const n = wrapNoise(lon, lat, 4, 7);
		const c = mix(deep, base, .35 + bands * .4 + n * .2);
		setPx(data, w, x, y, c[0], c[1], c[2]);
	}
}
function paintSun(data, w, h) {
	const core = [
		255,
		236,
		196
	];
	const limb = [
		255,
		164,
		64
	];
	const spot = [
		176,
		82,
		28
	];
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const lon = x / w * Math.PI * 2;
		const lat = y / h * Math.PI - Math.PI / 2;
		const gran = wrapNoise(lon, lat, 14, 1);
		const n = wrapNoise(lon, lat, 5, 3);
		let c = mix(limb, core, .35 + gran * .65);
		if (n > .72) c = mix(c, spot, (n - .72) * 3);
		setPx(data, w, x, y, c[0], c[1], c[2]);
	}
}
function createBodyTexture(kind, id) {
	const w = 512;
	const h = 256;
	const { canvas, data, put } = makeCanvas(w, h);
	if (kind === "sun") paintSun(data, w, h);
	else if (kind === "earth") paintEarth(data, w, h);
	else if (kind === "mars") paintMars(data, w, h);
	else if (kind === "venus") paintVenus(data, w, h);
	else if (kind === "rocky") paintRocky(data, w, h, [
		186,
		178,
		168
	], [
		92,
		86,
		80
	], .78);
	else if (kind === "gas") {
		if (id === "jupiter") paintGas(data, w, h, [
			214,
			176,
			128
		], [
			168,
			118,
			78
		], [
			236,
			214,
			176
		], {
			lat: .22,
			lon: 3.4,
			color: [
				176,
				72,
				48
			]
		});
		else paintGas(data, w, h, [
			232,
			210,
			160
		], [
			196,
			168,
			118
		], [
			244,
			228,
			186
		]);
	} else if (id === "neptune") paintIceGiant(data, w, h, [
		74,
		122,
		210
	], [
		22,
		48,
		120
	]);
	else paintIceGiant(data, w, h, [
		154,
		212,
		214
	], [
		48,
		110,
		126
	]);
	put();
	const texture = toTexture(canvas);
	texture.name = `body-${id}`;
	return texture;
}
function createCloudTexture() {
	const w = 512;
	const h = 256;
	const { canvas, data, put } = makeCanvas(w, h);
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const lon = x / w * Math.PI * 2;
		const lat = y / h * Math.PI - Math.PI / 2;
		const n = wrapNoise(lon, lat, 3.8, 11);
		const n2 = wrapNoise(lon, lat, 9, 14);
		const v = (n - .48) * 2.4 + n2 * .2;
		const a = Math.min(255, Math.max(0, v * 180));
		setPx(data, w, x, y, 236, 242, 248, a);
	}
	put();
	const texture = toTexture(canvas);
	texture.name = "clouds";
	return texture;
}
function createRingTexture() {
	const w = 4;
	const h = 512;
	const { canvas, data, put } = makeCanvas(w, h);
	for (let y = 0; y < h; y++) {
		const t = y / 511;
		let alpha = 1;
		if (t < .04 || t > .98) alpha = 0;
		else if (t > .58 && t < .66) alpha = .05;
		else if (t > .78 && t < .82) alpha = .15;
		else alpha = .35 + .45 * (.5 + .5 * Math.sin(t * 80));
		const shade = 180 + Math.floor(40 * Math.sin(t * 40));
		for (let x = 0; x < w; x++) setPx(data, w, x, y, shade, shade - 12, shade - 28, Math.floor(alpha * 255));
	}
	put();
	const texture = toTexture(canvas);
	texture.wrapT = ClampToEdgeWrapping;
	texture.name = "saturn-rings";
	return texture;
}
function createMoonTexture() {
	const w = 256;
	const h = 128;
	const { canvas, data, put } = makeCanvas(w, h);
	paintRocky(data, w, h, [
		176,
		174,
		168
	], [
		78,
		76,
		72
	], .7);
	put();
	return toTexture(canvas);
}
function disposeTexture(texture) {
	texture?.dispose();
}
function bodyRoughness(body) {
	if (body.texture === "gas" || body.texture === "ice-giant") return .55;
	if (body.texture === "venus") return .7;
	if (body.texture === "earth") return .62;
	return .86;
}
var OVERVIEW_POS = new Vector3(0, 46, 118);
var OVERVIEW_TARGET = new Vector3(0, 0, 0);
var _world = new Vector3();
var _proj = new Vector3();
var _dir = new Vector3();
var _tmp = new Vector3();
var _last = new Vector3();
function noopRaycast() {}
function Starfield() {
	const geometry = (0, import_react.useMemo)(() => {
		const n = 3600;
		const positions = new Float32Array(n * 3);
		for (let i = 0; i < n; i++) {
			const r = 90 + Math.random() * 130;
			const theta = Math.random() * Math.PI * 2;
			const phi = Math.acos(2 * Math.random() - 1);
			positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
			positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
			positions[i * 3 + 2] = r * Math.cos(phi);
		}
		const g = new BufferGeometry();
		g.setAttribute("position", new BufferAttribute(positions, 3));
		return g;
	}, []);
	(0, import_react.useLayoutEffect)(() => () => geometry.dispose(), [geometry]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("points", {
		geometry,
		frustumCulled: false,
		raycast: noopRaycast,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointsMaterial", {
			color: "#d5dbe6",
			size: .38,
			sizeAttenuation: true,
			transparent: true,
			opacity: .82,
			depthWrite: false
		})
	});
}
function WakeTrail({ bodyId, color }) {
	const length = 72;
	const primed = (0, import_react.useRef)(false);
	const sample = (0, import_react.useRef)(new Vector3());
	const { line, positions } = (0, import_react.useMemo)(() => {
		const pos = /* @__PURE__ */ new Float32Array(216);
		const cols = /* @__PURE__ */ new Float32Array(216);
		const c = new Color(color);
		for (let i = 0; i < length; i++) {
			const t = i / 71;
			const a = t * t;
			cols[i * 3] = c.r * a;
			cols[i * 3 + 1] = c.g * a;
			cols[i * 3 + 2] = c.b * a;
		}
		const geometry = new BufferGeometry();
		geometry.setAttribute("position", new BufferAttribute(pos, 3));
		geometry.setAttribute("color", new BufferAttribute(cols, 3));
		const material = new LineBasicMaterial({
			vertexColors: true,
			transparent: true,
			opacity: .88,
			depthWrite: false
		});
		const mesh = new Line(geometry, material);
		mesh.frustumCulled = false;
		mesh.raycast = noopRaycast;
		return {
			line: mesh,
			positions: pos
		};
	}, [color, length]);
	(0, import_react.useLayoutEffect)(() => () => {
		line.geometry.dispose();
		line.material.dispose();
	}, [line]);
	useFrame(() => {
		if (!useSim.getState().showTrails) return;
		const obj = bodyAnchors.get(bodyId);
		if (!obj) return;
		obj.getWorldPosition(sample.current);
		const p = sample.current;
		if (!Number.isFinite(p.x) || !Number.isFinite(p.y) || !Number.isFinite(p.z)) return;
		if (!primed.current) {
			for (let i = 0; i < length; i++) {
				positions[i * 3] = p.x;
				positions[i * 3 + 1] = p.y;
				positions[i * 3 + 2] = p.z;
			}
			primed.current = true;
		} else {
			positions.copyWithin(0, 3);
			const i = 213;
			positions[i] = p.x;
			positions[214] = p.y;
			positions[215] = p.z;
		}
		const attr = line.geometry.getAttribute("position");
		attr.needsUpdate = true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("primitive", { object: line });
}
function makeOrbitPoints(radius, segments = 160) {
	const pts = [];
	for (let i = 0; i <= segments; i++) {
		const a = i / segments * Math.PI * 2;
		pts.push(new Vector3(Math.cos(a) * radius, 0, Math.sin(a) * radius));
	}
	return pts;
}
function updateLabels(camera, width, height) {
	const show = useSim.getState().showLabels;
	for (const body of BODIES) {
		const el = labelNodes.get(body.id);
		if (!el) continue;
		if (!show) {
			el.style.opacity = "0";
			continue;
		}
		const obj = bodyAnchors.get(body.id);
		if (!obj) continue;
		obj.getWorldPosition(_world);
		_proj.copy(_world).project(camera);
		const visible = _proj.z > -1 && _proj.z < 1 && Math.abs(_proj.x) < 1.15 && Math.abs(_proj.y) < 1.15;
		const x = (_proj.x * .5 + .5) * width;
		const y = (-_proj.y * .5 + .5) * height;
		el.style.transform = `translate3d(${x}px, ${y}px, 0) translate(-50%, 0.7rem)`;
		el.style.opacity = visible ? "1" : "0";
	}
}
function CameraRig() {
	const camera = useThree((s) => s.camera);
	const size = useThree((s) => s.size);
	const selectedId = useSim((s) => s.selectedId);
	const focusNonce = useSim((s) => s.focusNonce);
	const framing = (0, import_react.useRef)(0);
	const armed = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		framing.current = 1.4;
		armed.current = false;
	}, [selectedId, focusNonce]);
	useFrame((state, delta) => {
		const d = Math.min(delta, .1);
		updateLabels(state.camera, size.width, size.height);
		const controls = state.controls;
		if (!controls) return;
		const body = selectedId ? BODY_BY_ID[selectedId] : null;
		const anchor = selectedId ? bodyAnchors.get(selectedId) : null;
		if (body && anchor) {
			anchor.getWorldPosition(_world);
			if (framing.current > 0) {
				const dist = body.radius * (body.id === "sun" ? 4.6 : 6.6) + (body.hasRings ? 3.4 : 2.4);
				_dir.copy(camera.position).sub(controls.target);
				if (_dir.lengthSq() < 1e-6) _dir.set(.45, .36, 1);
				_dir.normalize();
				_tmp.copy(_world).addScaledVector(_dir, dist);
				const k = 1 - Math.exp(-3.15 * d);
				camera.position.lerp(_tmp, k);
				controls.target.lerp(_world, k);
				framing.current -= d;
				_last.copy(_world);
				armed.current = true;
			} else {
				if (!armed.current) {
					_last.copy(_world);
					armed.current = true;
				} else {
					_dir.copy(_world).sub(_last);
					camera.position.add(_dir);
					controls.target.add(_dir);
				}
				_last.copy(_world);
			}
			controls.minDistance = Math.max(body.radius * 2.15, 1.6);
			controls.maxDistance = body.radius * 30 + 24;
		} else {
			if (framing.current > 0) {
				const k = 1 - Math.exp(-2.35 * d);
				camera.position.lerp(OVERVIEW_POS, k);
				controls.target.lerp(OVERVIEW_TARGET, k);
				framing.current -= d;
			}
			controls.minDistance = 8;
			controls.maxDistance = 180;
			armed.current = false;
		}
		controls.update();
	});
	return null;
}
function Sun() {
	const spinRef = (0, import_react.useRef)(null);
	const texture = (0, import_react.useMemo)(() => createBodyTexture("sun", "sun"), []);
	const glowMat = (0, import_react.useMemo)(() => new ShaderMaterial({
		transparent: true,
		depthWrite: false,
		blending: 2,
		vertexShader: `
          varying vec2 vUv;
          void main() {
            vUv = uv;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
		fragmentShader: `
          varying vec2 vUv;
          void main() {
            vec2 p = vUv - vec2(0.5);
            float d = length(p);
            float core = smoothstep(0.18, 0.0, d);
            float halo = pow(smoothstep(0.5, 0.0, d), 1.6);
            vec3 col = mix(vec3(1.0, 0.55, 0.18), vec3(1.0, 0.92, 0.72), core);
            gl_FragColor = vec4(col, halo * 0.72);
          }
        `
	}), []);
	(0, import_react.useLayoutEffect)(() => {
		return () => {
			disposeTexture(texture);
			glowMat.dispose();
		};
	}, [texture, glowMat]);
	const { camera } = useThree();
	const billboard = (0, import_react.useRef)(null);
	useFrame((_, delta) => {
		const d = Math.min(delta, .1);
		const { paused, speed } = useSim.getState();
		billboard.current?.quaternion.copy(camera.quaternion);
		if (spinRef.current && !paused) spinRef.current.rotation.y += d * speed * Math.PI * 2 / (SUN.dayLength * 5);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
			ref: (node) => {
				spinRef.current = node;
				if (node) bodyAnchors.set("sun", node);
				else bodyAnchors.delete("sun");
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				onClick: (e) => {
					e.stopPropagation();
					useSim.getState().focus("sun");
				},
				onPointerOver: () => {
					document.body.style.cursor = "pointer";
				},
				onPointerOut: () => {
					document.body.style.cursor = "auto";
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					SUN.radius,
					64,
					48
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", { map: texture })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				scale: 1.08,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					SUN.radius,
					32,
					24
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
					color: "#ffb35c",
					transparent: true,
					opacity: .18,
					blending: 2,
					depthWrite: false
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			ref: billboard,
			scale: SUN.radius * 3.4,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [1, 1] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("primitive", {
				object: glowMat,
				attach: "material"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			color: "#fff1d4",
			intensity: 380,
			distance: 0,
			decay: 1.05
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			color: "#ffd19a",
			intensity: 18,
			distance: 16,
			decay: 2
		})
	] });
}
function Planet({ body, orbitRef, spinRef, moonRef, cloudRef }) {
	const texture = (0, import_react.useMemo)(() => createBodyTexture(body.texture, body.id), [body.id, body.texture]);
	const clouds = (0, import_react.useMemo)(() => body.hasClouds ? createCloudTexture() : null, [body.hasClouds]);
	const rings = (0, import_react.useMemo)(() => body.hasRings ? createRingTexture() : null, [body.hasRings]);
	const moon = (0, import_react.useMemo)(() => body.hasMoon ? createMoonTexture() : null, [body.hasMoon]);
	const posRef = (0, import_react.useRef)(null);
	(0, import_react.useLayoutEffect)(() => {
		const node = posRef.current;
		if (node) bodyAnchors.set(body.id, node);
		return () => {
			bodyAnchors.delete(body.id);
			disposeTexture(texture);
			disposeTexture(clouds);
			disposeTexture(rings);
			disposeTexture(moon);
		};
	}, [
		body.id,
		texture,
		clouds,
		rings,
		moon
	]);
	const tilt = body.tilt * Math.PI / 180;
	const inclination = body.inclination * Math.PI / 180;
	const hitRadius = Math.max(body.radius * 1.7, .85);
	const roughness = bodyRoughness(body);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		rotation: [
			inclination,
			0,
			0
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			ref: orbitRef,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
				ref: posRef,
				position: [
					body.distance,
					0,
					0
				],
				onClick: (e) => {
					e.stopPropagation();
					useSim.getState().focus(body.id);
				},
				onPointerOver: () => {
					document.body.style.cursor = "pointer";
				},
				onPointerOut: () => {
					document.body.style.cursor = "auto";
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
						rotation: [
							0,
							0,
							tilt
						],
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
								ref: spinRef,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
									body.radius,
									48,
									36
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
									map: texture,
									roughness,
									metalness: .04,
									emissive: body.texture === "gas" ? body.swatch : "#000000",
									emissiveIntensity: body.texture === "gas" ? .04 : 0
								})] })
							}),
							clouds ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
								ref: cloudRef,
								scale: 1.025,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
									body.radius,
									48,
									36
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
									map: clouds,
									transparent: true,
									depthWrite: false,
									roughness: 1,
									metalness: 0
								})]
							}) : null,
							rings ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
								rotation: [
									Math.PI / 2,
									0,
									0
								],
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
									body.radius * 1.35,
									body.radius * 2.25,
									96
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
									map: rings,
									transparent: true,
									side: 2,
									depthWrite: false,
									roughness: .7,
									metalness: .08
								})]
							}) : null
						]
					}),
					body.hasMoon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
						ref: moonRef,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
							position: [
								body.radius * 2.55,
								.12,
								0
							],
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
								body.radius * .27,
								24,
								18
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
								map: moon,
								roughness: .95,
								metalness: 0
							})]
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
						visible: false,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
							hitRadius,
							8,
							8
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {})]
					})
				]
			})
		})
	});
}
function OrbitPath({ body }) {
	const object = (0, import_react.useMemo)(() => {
		const geometry = new BufferGeometry().setFromPoints(makeOrbitPoints(body.distance));
		const material = new LineBasicMaterial({
			color: body.trail,
			transparent: true,
			opacity: .28
		});
		const loop = new LineLoop(geometry, material);
		loop.raycast = noopRaycast;
		return loop;
	}, [body.distance, body.trail]);
	(0, import_react.useLayoutEffect)(() => () => {
		object.geometry.dispose();
		object.material.dispose();
	}, [object]);
	const inclination = body.inclination * Math.PI / 180;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		rotation: [
			inclination,
			0,
			0
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("primitive", { object })
	});
}
function AsteroidBelt({ groupRef }) {
	const count = 420;
	const meshRef = (0, import_react.useRef)(null);
	const geometry = (0, import_react.useMemo)(() => new SphereGeometry(1, 6, 5), []);
	const material = (0, import_react.useMemo)(() => new MeshStandardMaterial({
		color: "#7a756e",
		roughness: 1,
		metalness: .08
	}), []);
	(0, import_react.useLayoutEffect)(() => {
		const mesh = meshRef.current;
		if (!mesh) return;
		const dummy = new Object3D();
		for (let i = 0; i < count; i++) {
			const a = i / count * Math.PI * 2 + hash(i) * .4;
			const r = 29.4 + hash(i + 17) * 5.6;
			dummy.position.set(Math.cos(a) * r, (hash(i + 31) - .5) * .7, Math.sin(a) * r);
			const s = .03 + hash(i + 53) * .09;
			dummy.scale.set(s, s * (.7 + hash(i + 71) * .6), s);
			dummy.rotation.set(hash(i + 3) * 6, hash(i + 5) * 6, hash(i + 7) * 6);
			dummy.updateMatrix();
			mesh.setMatrixAt(i, dummy.matrix);
		}
		mesh.instanceMatrix.needsUpdate = true;
		return () => {
			geometry.dispose();
			material.dispose();
		};
	}, [
		count,
		geometry,
		material
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		ref: groupRef,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("instancedMesh", {
			ref: meshRef,
			args: [
				geometry,
				material,
				count
			],
			raycast: noopRaycast
		})
	});
}
function hash(i) {
	const n = Math.sin(i * 127.1 + 311.7) * 43758.5453;
	return n - Math.floor(n);
}
function System() {
	const orbitRefs = (0, import_react.useRef)({});
	const spinRefs = (0, import_react.useRef)({});
	const moonRef = (0, import_react.useRef)(null);
	const cloudRef = (0, import_react.useRef)(null);
	const beltRef = (0, import_react.useRef)(null);
	const acc = (0, import_react.useRef)(0);
	const showOrbits = useSim((s) => s.showOrbits);
	const showTrails = useSim((s) => s.showTrails);
	useFrame((_, delta) => {
		const d = Math.min(delta, .1);
		const { paused, speed, setSimDays } = useSim.getState();
		if (!paused) simClock.days += d * speed * DAYS_PER_REAL_SECOND;
		const days = simClock.days;
		const years = days / 365.25;
		for (const body of PLANETS) {
			const orbit = orbitRefs.current[body.id];
			if (orbit) orbit.rotation.y = years / body.orbitYears * Math.PI * 2 + body.phase;
			const spin = spinRefs.current[body.id];
			if (spin && !paused) {
				const dir = body.dayLength < 0 ? -1 : 1;
				const period = Math.max(Math.abs(body.dayLength), .28);
				spin.rotation.y += dir * d * speed * Math.PI * 2 / (period * 5);
			}
		}
		if (moonRef.current) moonRef.current.rotation.y = days / 27.3 * Math.PI * 2;
		if (cloudRef.current && !paused) cloudRef.current.rotation.y += d * speed * .1;
		if (beltRef.current) beltRef.current.rotation.y = years * .18;
		acc.current += d;
		if (acc.current > .25) {
			acc.current = 0;
			setSimDays(days);
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {}),
		showOrbits ? PLANETS.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitPath, { body }, `orbit-${body.id}`)) : null,
		showTrails ? PLANETS.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WakeTrail, {
			bodyId: body.id,
			color: body.trail
		}, `trail-${body.id}`)) : null,
		PLANETS.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Planet, {
			body,
			orbitRef: (node) => {
				orbitRefs.current[body.id] = node;
			},
			spinRef: (node) => {
				spinRefs.current[body.id] = node;
			},
			moonRef: body.hasMoon ? (node) => {
				moonRef.current = node;
			} : void 0,
			cloudRef: body.hasClouds ? (node) => {
				cloudRef.current = node;
			} : void 0
		}, body.id)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AsteroidBelt, { groupRef: (node) => {
			beltRef.current = node;
		} })
	] });
}
function SceneLights() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
			attach: "background",
			args: ["#07080b"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("fog", {
			attach: "fog",
			args: [
				"#07080b",
				170,
				340
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", {
			intensity: .07,
			color: "#cdd6e4"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", { args: [
			"#1a2438",
			"#09090c",
			.22
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, {})
	] });
}
function SolarScene() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Canvas, {
		className: "touch-none h-full w-full",
		camera: {
			position: [
				0,
				46,
				118
			],
			fov: 42,
			near: .1,
			far: 400
		},
		dpr: [1, 1.75],
		gl: {
			antialias: true,
			alpha: false,
			powerPreference: "high-performance"
		},
		onCreated: ({ gl }) => {
			gl.toneMapping = 4;
			gl.toneMappingExposure = 1.08;
			gl.setClearColor("#07080b", 1);
		},
		onPointerMissed: () => {
			useSim.getState().clearFocus();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SceneLights, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(System, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraRig, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitControls, {
				makeDefault: true,
				enableDamping: true,
				dampingFactor: .08,
				rotateSpeed: .55,
				zoomSpeed: .72,
				panSpeed: .4,
				minPolarAngle: .18,
				maxPolarAngle: Math.PI - .18,
				enablePan: true
			})
		]
	});
}
function SolarApp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "sr-only",
				children: "Órbita — explorador del sistema solar"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SolarScene, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay, {})
		]
	});
}
//#endregion
export { SolarApp as default };
