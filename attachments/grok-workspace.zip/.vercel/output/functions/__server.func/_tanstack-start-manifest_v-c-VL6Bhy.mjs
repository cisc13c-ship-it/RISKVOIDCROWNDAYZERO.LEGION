//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-c-VL6Bhy.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DsPOOe8r.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DsPOOe8r.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-n9-x9Chh.js"]
	}
} });
//#endregion
export { tsrStartManifest };
