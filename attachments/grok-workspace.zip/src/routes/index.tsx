import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ComponentType } from "react";
import { BootScreen } from "@/components/solar-system/boot-screen";

const solarAppImport =
  typeof window !== "undefined" ? import("@/components/solar-system/solar-app") : null;

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [App, setApp] = useState<ComponentType | null>(null);

  useEffect(() => {
    let alive = true;
    void (solarAppImport ?? import("@/components/solar-system/solar-app")).then((mod) => {
      if (alive) setApp(() => mod.default);
    });
    return () => {
      alive = false;
    };
  }, []);

  if (!App) return <BootScreen />;
  return <App />;
}
