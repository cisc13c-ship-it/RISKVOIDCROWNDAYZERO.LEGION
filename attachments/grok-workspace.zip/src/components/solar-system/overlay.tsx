import { useEffect, type ReactNode } from "react";
import {
  Eye,
  EyeOff,
  Pause,
  Play,
  RotateCcw,
  Spline,
  Orbit,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  BODIES,
  BODY_BY_ID,
  formatSimTime,
  formatSpeed,
  sliderFromSpeed,
  speedFromSlider,
} from "@/lib/solar/bodies";
import { labelNodes } from "@/lib/solar/anchors";
import { useSim } from "@/lib/solar/store";
import { cn } from "@/lib/utils";

export function Overlay() {
  const paused = useSim((s) => s.paused);
  const speed = useSim((s) => s.speed);
  const selectedId = useSim((s) => s.selectedId);
  const showLabels = useSim((s) => s.showLabels);
  const showOrbits = useSim((s) => s.showOrbits);
  const showTrails = useSim((s) => s.showTrails);
  const simDays = useSim((s) => s.simDays);
  const selected = selectedId ? BODY_BY_ID[selectedId] : null;
  const time = formatSimTime(simDays);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.code === "Space") {
        e.preventDefault();
        useSim.getState().togglePaused();
      } else if (e.code === "Escape") {
        useSim.getState().focus(null);
      } else if (e.key === "[" || e.key === "-") {
        useSim.getState().setSpeed(Math.max(0.25, speed * 0.7));
      } else if (e.key === "]" || e.key === "+" || e.key === "=") {
        useSim.getState().setSpeed(Math.min(50, speed * 1.4));
      } else if (e.key === "l" || e.key === "L") {
        useSim.getState().setShowLabels(!useSim.getState().showLabels);
      } else if (e.key === "o" || e.key === "O") {
        useSim.getState().setShowOrbits(!useSim.getState().showOrbits);
      } else if (e.key === "t" || e.key === "T") {
        useSim.getState().setShowTrails(!useSim.getState().showTrails);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [speed]);

  return (
    <div className="pointer-events-none absolute inset-0 z-10 text-fg">
      <div className="vignette absolute inset-0" />

      {BODIES.map((body) => (
        <div
          key={body.id}
          data-body={body.id}
          data-selected={selectedId === body.id ? "true" : "false"}
          ref={(node) => {
            if (node) labelNodes.set(body.id, node);
            else labelNodes.delete(body.id);
          }}
          className="planet-label pointer-events-none absolute top-0 left-0"
        >
          {body.name}
        </div>
      ))}

      <header className="pointer-events-none flex items-start justify-between gap-4 p-4 md:p-6">
        <div className="max-w-[16rem]">
          <p className="text-[11px] tracking-[0.32em] text-muted uppercase">Observatorio</p>
          <h1 className="font-display text-4xl leading-none tracking-tight italic md:text-5xl">
            Órbita
          </h1>
          <p className="mt-2 max-w-[14rem] text-sm leading-snug text-muted">
            Arrastra para girar. Pulsa un mundo para acercarte.
          </p>
        </div>

        <div className="pointer-events-auto flex items-center gap-1 rounded-2xl bg-surface/80 p-1 shadow-[var(--shadow-border)]">
          <Toggle
            pressed={showLabels}
            onPressed={() => useSim.getState().setShowLabels(!showLabels)}
            label={showLabels ? "Ocultar etiquetas" : "Mostrar etiquetas"}
          >
            {showLabels ? <Eye className="size-4" /> : <EyeOff className="size-4" />}
          </Toggle>
          <Toggle
            pressed={showOrbits}
            onPressed={() => useSim.getState().setShowOrbits(!showOrbits)}
            label={showOrbits ? "Ocultar órbitas" : "Mostrar órbitas"}
          >
            <Orbit className="size-4" />
          </Toggle>
          <Toggle
            pressed={showTrails}
            onPressed={() => useSim.getState().setShowTrails(!showTrails)}
            label={showTrails ? "Ocultar estelas" : "Mostrar estelas"}
          >
            <Spline className="size-4" />
          </Toggle>
        </div>
      </header>

      <div className="absolute top-28 bottom-36 left-4 hidden w-52 flex-col md:flex lg:top-32 lg:bottom-32 lg:left-6">
        <nav className="pointer-events-auto overflow-hidden rounded-2xl bg-surface/80 p-2 shadow-[var(--shadow-border)]">
          <p className="px-3 pt-2 pb-1 text-[11px] tracking-[0.22em] text-muted uppercase">
            Cuerpos
          </p>
          <ul className="flex flex-col">
            {BODIES.map((body) => (
              <li key={body.id}>
                <button
                  type="button"
                  onClick={() => useSim.getState().focus(body.id)}
                  className={cn(
                    "flex h-11 w-full items-center gap-3 rounded-xl px-3 text-left text-sm transition-[background-color,color] duration-[length:var(--motion-quick)]",
                    selectedId === body.id
                      ? "bg-fg/8 text-fg"
                      : "text-muted hover:bg-fg/5 hover:text-fg",
                  )}
                >
                  <span
                    data-body={body.id}
                    className="swatch size-2.5 shrink-0 rounded-full"
                    aria-hidden="true"
                  />
                  <span className="flex-1 truncate">{body.name}</span>
                  {body.kind === "star" ? (
                    <span className="text-[10px] tracking-wider text-subtle uppercase">
                      estrella
                    </span>
                  ) : null}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      {selected ? (
        <aside className="pointer-events-auto panel-enter absolute right-4 bottom-36 max-h-[min(52vh,28rem)] w-[min(calc(100%-2rem),20.5rem)] overflow-auto rounded-2xl bg-surface/80 p-4 shadow-[var(--shadow-border)] md:top-32 md:right-6 md:bottom-32 md:max-h-none md:w-80 md:p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-[11px] tracking-[0.22em] text-muted uppercase">
                {selected.subtitle}
              </p>
              <h2 className="font-display mt-1 text-3xl leading-none italic">{selected.name}</h2>
            </div>
            <span
              data-body={selected.id}
              className="swatch mt-1 size-3 rounded-full"
              aria-hidden="true"
            />
          </div>
          <p className="mt-4 text-sm leading-relaxed text-pretty text-muted">
            {selected.description}
          </p>
          <dl className="mt-5 grid grid-cols-2 gap-x-4 gap-y-3">
            {selected.facts.map((fact) => (
              <div key={fact.label}>
                <dt className="text-[11px] tracking-[0.18em] text-subtle uppercase">
                  {fact.label}
                </dt>
                <dd className="mt-1 text-sm tabular-nums">{fact.value}</dd>
              </div>
            ))}
          </dl>
        </aside>
      ) : null}

      <footer className="pointer-events-none absolute inset-x-0 bottom-0 p-4 md:p-6">
        <div className="mb-3 flex gap-2 overflow-x-auto pb-1 md:hidden">
          {BODIES.map((body) => (
            <button
              key={body.id}
              type="button"
              onClick={() => useSim.getState().focus(body.id)}
              className={cn(
                "pointer-events-auto flex h-11 shrink-0 items-center gap-2 rounded-full px-3.5 text-sm shadow-[var(--shadow-border)]",
                selectedId === body.id ? "bg-accent text-accent-fg" : "bg-surface/85 text-fg",
              )}
            >
              <span data-body={body.id} className="swatch size-2 rounded-full" aria-hidden="true" />
              {body.name}
            </button>
          ))}
        </div>

        <div className="pointer-events-auto mx-auto flex max-w-3xl flex-col gap-3 rounded-2xl bg-surface/85 p-2 shadow-[var(--shadow-border)] md:flex-row md:items-center md:gap-4 md:rounded-2xl md:p-2 md:pr-4">
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              aria-label={paused ? "Reanudar" : "Pausa"}
              onClick={() => useSim.getState().togglePaused()}
            >
              {paused ? (
                <Play className="size-4 translate-x-px" />
              ) : (
                <Pause className="size-4" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Vista general"
              onClick={() => useSim.getState().focus(null)}
            >
              <RotateCcw className="size-4" />
            </Button>
            <div className="hidden h-8 w-px bg-border md:block" />
            <div className="hidden px-2 md:block">
              <p className="text-[10px] tracking-[0.2em] text-subtle uppercase">Año</p>
              <p className="font-medium tabular-nums leading-tight">{time.year}</p>
            </div>
          </div>

          <div className="flex min-w-0 flex-1 items-center gap-3 px-2 pb-1 md:pb-0">
            <label htmlFor="sim-speed" className="shrink-0 text-[11px] tracking-[0.18em] text-muted uppercase">
              Velocidad
            </label>
            <Slider
              id="sim-speed"
              min={0}
              max={1}
              step={0.01}
              value={[sliderFromSpeed(speed)]}
              onValueChange={([t]) => {
                if (typeof t === "number") useSim.getState().setSpeed(speedFromSlider(t));
              }}
              aria-label="Velocidad de simulación"
            />
            <span className="w-12 shrink-0 text-right text-sm tabular-nums">{formatSpeed(speed)}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Toggle({
  pressed,
  onPressed,
  label,
  children,
}: {
  pressed: boolean;
  onPressed: () => void;
  label: string;
  children: ReactNode;
}) {
  return (
    <Button
      type="button"
      variant="ghost"
      size="icon-sm"
      aria-label={label}
      aria-pressed={pressed}
      onClick={onPressed}
      className={cn(pressed ? "text-fg" : "text-subtle")}
    >
      {children}
    </Button>
  );
}
