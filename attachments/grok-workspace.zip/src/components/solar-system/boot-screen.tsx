export function BootScreen() {
  return (
    <div className="flex h-dvh w-full flex-col items-center justify-center bg-bg text-fg">
      <div className="relative size-14" aria-hidden="true">
        <span className="absolute inset-[-14px] rounded-full border border-fg/8" />
        <span className="absolute inset-[-6px] rounded-full border border-fg/14" />
        <span className="absolute inset-0 rounded-full bg-accent/90" />
        <span className="boot-orbit absolute inset-[-14px]">
          <span className="absolute top-0 left-1/2 size-1.5 -translate-x-1/2 rounded-full bg-fg" />
        </span>
      </div>
      <p className="mt-10 font-display text-4xl tracking-tight italic">Órbita</p>
      <p className="mt-2 text-xs tracking-[0.28em] text-muted uppercase">Sistema solar</p>
    </div>
  );
}
