import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import * as THREE from "three";
import {
  BODIES,
  BODY_BY_ID,
  DAYS_PER_REAL_SECOND,
  EARTH_SPIN_SECONDS,
  PLANETS,
  SUN,
  type BodyId,
  type CelestialBody,
} from "@/lib/solar/bodies";
import { bodyAnchors, labelNodes, simClock } from "@/lib/solar/anchors";
import { useSim } from "@/lib/solar/store";
import {
  bodyRoughness,
  createBodyTexture,
  createCloudTexture,
  createMoonTexture,
  createRingTexture,
  disposeTexture,
} from "@/lib/solar/textures";

const OVERVIEW_POS = new THREE.Vector3(0, 46, 118);
const OVERVIEW_TARGET = new THREE.Vector3(0, 0, 0);
const _world = new THREE.Vector3();
const _proj = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _tmp = new THREE.Vector3();
const _last = new THREE.Vector3();

type ControlsLike = {
  target: THREE.Vector3;
  update: () => void;
  minDistance: number;
  maxDistance: number;
};

function noopRaycast() {}

function Starfield() {
  const geometry = useMemo(() => {
    const n = 3600;
    const positions = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const r = 90 + Math.random() * 130;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    return g;
  }, []);

  useLayoutEffect(() => () => geometry.dispose(), [geometry]);

  return (
    <points geometry={geometry} frustumCulled={false} raycast={noopRaycast}>
      <pointsMaterial
        color="#d5dbe6"
        size={0.38}
        sizeAttenuation
        transparent
        opacity={0.82}
        depthWrite={false}
      />
    </points>
  );
}

function WakeTrail({ bodyId, color }: { bodyId: BodyId; color: string }) {
  const length = 72;
  const primed = useRef(false);
  const sample = useRef(new THREE.Vector3());
  const { line, positions } = useMemo(() => {
    const pos = new Float32Array(length * 3);
    const cols = new Float32Array(length * 3);
    const c = new THREE.Color(color);
    for (let i = 0; i < length; i++) {
      const t = i / (length - 1);
      const a = t * t;
      cols[i * 3] = c.r * a;
      cols[i * 3 + 1] = c.g * a;
      cols[i * 3 + 2] = c.b * a;
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    geometry.setAttribute("color", new THREE.BufferAttribute(cols, 3));
    const material = new THREE.LineBasicMaterial({
      vertexColors: true,
      transparent: true,
      opacity: 0.88,
      depthWrite: false,
    });
    const mesh = new THREE.Line(geometry, material);
    mesh.frustumCulled = false;
    mesh.raycast = noopRaycast;
    return { line: mesh, positions: pos };
  }, [color, length]);

  useLayoutEffect(
    () => () => {
      line.geometry.dispose();
      (line.material as THREE.Material).dispose();
    },
    [line],
  );

  useFrame(() => {
    if (!useSim.getState().showTrails) return;
    const obj = bodyAnchors.get(bodyId);
    if (!obj) return;
    obj.getWorldPosition(sample.current);
    const p = sample.current;
    if (!Number.isFinite(p.x) || !Number.isFinite(p.y) || !Number.isFinite(p.z)) return;

    if (!primed.current) {
      for (let i = 0; i < length; i++) {
        positions[i * 3] = p.x;
        positions[i * 3 + 1] = p.y;
        positions[i * 3 + 2] = p.z;
      }
      primed.current = true;
    } else {
      positions.copyWithin(0, 3);
      const i = (length - 1) * 3;
      positions[i] = p.x;
      positions[i + 1] = p.y;
      positions[i + 2] = p.z;
    }
    const attr = line.geometry.getAttribute("position");
    attr.needsUpdate = true;
  });

  return <primitive object={line} />;
}

function makeOrbitPoints(radius: number, segments = 160): THREE.Vector3[] {
  const pts: THREE.Vector3[] = [];
  for (let i = 0; i <= segments; i++) {
    const a = (i / segments) * Math.PI * 2;
    pts.push(new THREE.Vector3(Math.cos(a) * radius, 0, Math.sin(a) * radius));
  }
  return pts;
}

function updateLabels(camera: THREE.Camera, width: number, height: number) {
  const show = useSim.getState().showLabels;
  for (const body of BODIES) {
    const el = labelNodes.get(body.id);
    if (!el) continue;
    if (!show) {
      el.style.opacity = "0";
      continue;
    }
    const obj = bodyAnchors.get(body.id);
    if (!obj) continue;
    obj.getWorldPosition(_world);
    _proj.copy(_world).project(camera);
    const visible = _proj.z > -1 && _proj.z < 1 && Math.abs(_proj.x) < 1.15 && Math.abs(_proj.y) < 1.15;
    const x = (_proj.x * 0.5 + 0.5) * width;
    const y = (-_proj.y * 0.5 + 0.5) * height;
    el.style.transform = `translate3d(${x}px, ${y}px, 0) translate(-50%, 0.7rem)`;
    el.style.opacity = visible ? "1" : "0";
  }
}

function CameraRig() {
  const camera = useThree((s) => s.camera);
  const size = useThree((s) => s.size);
  const selectedId = useSim((s) => s.selectedId);
  const focusNonce = useSim((s) => s.focusNonce);
  const framing = useRef(0);
  const armed = useRef(false);

  useEffect(() => {
    framing.current = 1.4;
    armed.current = false;
  }, [selectedId, focusNonce]);

  useFrame((state, delta) => {
    const d = Math.min(delta, 0.1);
    updateLabels(state.camera, size.width, size.height);
    const controls = state.controls as unknown as ControlsLike | undefined;
    if (!controls) return;

    const body = selectedId ? BODY_BY_ID[selectedId] : null;
    const anchor = selectedId ? bodyAnchors.get(selectedId) : null;

    if (body && anchor) {
      anchor.getWorldPosition(_world);
      if (framing.current > 0) {
        const dist =
          body.radius * (body.id === "sun" ? 4.6 : 6.6) + (body.hasRings ? 3.4 : 2.4);
        _dir.copy(camera.position).sub(controls.target);
        if (_dir.lengthSq() < 1e-6) _dir.set(0.45, 0.36, 1);
        _dir.normalize();
        _tmp.copy(_world).addScaledVector(_dir, dist);
        const k = 1 - Math.exp(-3.15 * d);
        camera.position.lerp(_tmp, k);
        controls.target.lerp(_world, k);
        framing.current -= d;
        _last.copy(_world);
        armed.current = true;
      } else {
        if (!armed.current) {
          _last.copy(_world);
          armed.current = true;
        } else {
          _dir.copy(_world).sub(_last);
          camera.position.add(_dir);
          controls.target.add(_dir);
        }
        _last.copy(_world);
      }
      controls.minDistance = Math.max(body.radius * 2.15, 1.6);
      controls.maxDistance = body.radius * 30 + 24;
    } else {
      if (framing.current > 0) {
        const k = 1 - Math.exp(-2.35 * d);
        camera.position.lerp(OVERVIEW_POS, k);
        controls.target.lerp(OVERVIEW_TARGET, k);
        framing.current -= d;
      }
      controls.minDistance = 8;
      controls.maxDistance = 180;
      armed.current = false;
    }

    controls.update();
  });

  return null;
}

function Sun() {
  const spinRef = useRef<THREE.Group>(null);
  const [texture, setTexture] = useState<THREE.CanvasTexture | null>(null);
  const glowMat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        vertexShader: `
          varying vec2 vUv;
          void main() {
            vUv = uv;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          varying vec2 vUv;
          void main() {
            vec2 p = vUv - vec2(0.5);
            float d = length(p);
            float core = smoothstep(0.18, 0.0, d);
            float halo = pow(smoothstep(0.5, 0.0, d), 1.6);
            vec3 col = mix(vec3(1.0, 0.55, 0.18), vec3(1.0, 0.92, 0.72), core);
            gl_FragColor = vec4(col, halo * 0.72);
          }
        `,
      }),
    [],
  );

  useEffect(() => {
    const map = createBodyTexture("sun", "sun");
    setTexture(map);
    return () => {
      disposeTexture(map);
    };
  }, []);

  useLayoutEffect(() => {
    return () => {
      glowMat.dispose();
    };
  }, [glowMat]);

  const { camera } = useThree();
  const billboard = useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    const d = Math.min(delta, 0.1);
    const { paused, speed } = useSim.getState();
    billboard.current?.quaternion.copy(camera.quaternion);
    if (spinRef.current && !paused) {
      spinRef.current.rotation.y +=
        (d * speed * Math.PI * 2) / (SUN.dayLength * EARTH_SPIN_SECONDS);
    }
  });

  return (
    <group>
      <group
        ref={(node) => {
          spinRef.current = node;
          if (node) bodyAnchors.set("sun", node);
          else bodyAnchors.delete("sun");
        }}
      >
        <mesh
          onClick={(e) => {
            e.stopPropagation();
            useSim.getState().focus("sun");
          }}
          onPointerOver={() => {
            document.body.style.cursor = "pointer";
          }}
          onPointerOut={() => {
            document.body.style.cursor = "auto";
          }}
        >
          <sphereGeometry args={[SUN.radius, 64, 48]} />
          <meshBasicMaterial color="#ffc878" map={texture} />
        </mesh>
        <mesh scale={1.08}>
          <sphereGeometry args={[SUN.radius, 32, 24]} />
          <meshBasicMaterial
            color="#ffb35c"
            transparent
            opacity={0.18}
            blending={THREE.AdditiveBlending}
            depthWrite={false}
          />
        </mesh>
      </group>
      <mesh ref={billboard} scale={SUN.radius * 3.4}>
        <planeGeometry args={[1, 1]} />
        <primitive object={glowMat} attach="material" />
      </mesh>
      <pointLight color="#fff1d4" intensity={380} distance={0} decay={1.05} />
      <pointLight color="#ffd19a" intensity={18} distance={16} decay={2} />
    </group>
  );
}

function Planet({
  body,
  orbitRef,
  spinRef,
  moonRef,
  cloudRef,
}: {
  body: CelestialBody;
  orbitRef: (node: THREE.Group | null) => void;
  spinRef: (node: THREE.Group | null) => void;
  moonRef?: (node: THREE.Group | null) => void;
  cloudRef?: (node: THREE.Mesh | null) => void;
}) {
  const [texture, setTexture] = useState<THREE.CanvasTexture | null>(null);
  const [clouds, setClouds] = useState<THREE.CanvasTexture | null>(null);
  const [rings, setRings] = useState<THREE.CanvasTexture | null>(null);
  const [moon, setMoon] = useState<THREE.CanvasTexture | null>(null);
  const posRef = useRef<THREE.Group>(null);

  useLayoutEffect(() => {
    const node = posRef.current;
    if (node) bodyAnchors.set(body.id, node);
    return () => {
      bodyAnchors.delete(body.id);
    };
  }, [body.id]);

  useEffect(() => {
    const map = createBodyTexture(body.texture, body.id);
    setTexture(map);
    const cloudMap = body.hasClouds ? createCloudTexture() : null;
    const ringMap = body.hasRings ? createRingTexture() : null;
    const moonMap = body.hasMoon ? createMoonTexture() : null;
    setClouds(cloudMap);
    setRings(ringMap);
    setMoon(moonMap);
    return () => {
      disposeTexture(map);
      disposeTexture(cloudMap);
      disposeTexture(ringMap);
      disposeTexture(moonMap);
    };
  }, [body.id, body.texture, body.hasClouds, body.hasRings, body.hasMoon]);

  const tilt = (body.tilt * Math.PI) / 180;
  const inclination = (body.inclination * Math.PI) / 180;
  const hitRadius = Math.max(body.radius * 1.7, 0.85);
  const roughness = bodyRoughness(body);

  return (
    <group rotation={[inclination, 0, 0]}>
      <group ref={orbitRef}>
        <group
          ref={posRef}
          position={[body.distance, 0, 0]}
          onClick={(e) => {
            e.stopPropagation();
            useSim.getState().focus(body.id);
          }}
          onPointerOver={() => {
            document.body.style.cursor = "pointer";
          }}
          onPointerOut={() => {
            document.body.style.cursor = "auto";
          }}
        >
          <group rotation={[0, 0, tilt]}>
            <group ref={spinRef}>
              <mesh>
                <sphereGeometry args={[body.radius, 48, 36]} />
                <meshStandardMaterial
                  color={body.swatch}
                  map={texture}
                  roughness={roughness}
                  metalness={0.04}
                  emissive={body.texture === "gas" ? body.swatch : "#000000"}
                  emissiveIntensity={body.texture === "gas" ? 0.04 : 0}
                />
              </mesh>
            </group>
            {clouds ? (
              <mesh ref={cloudRef} scale={1.025}>
                <sphereGeometry args={[body.radius, 48, 36]} />
                <meshStandardMaterial
                  map={clouds}
                  transparent
                  depthWrite={false}
                  roughness={1}
                  metalness={0}
                />
              </mesh>
            ) : null}
            {rings ? (
              <mesh rotation={[Math.PI / 2, 0, 0]}>
                <ringGeometry args={[body.radius * 1.35, body.radius * 2.25, 96]} />
                <meshStandardMaterial
                  map={rings}
                  transparent
                  side={THREE.DoubleSide}
                  depthWrite={false}
                  roughness={0.7}
                  metalness={0.08}
                />
              </mesh>
            ) : null}
          </group>
          {body.hasMoon ? (
            <group ref={moonRef}>
              <mesh position={[body.radius * 2.55, 0.12, 0]}>
                <sphereGeometry args={[body.radius * 0.27, 24, 18]} />
                <meshStandardMaterial map={moon} roughness={0.95} metalness={0} />
              </mesh>
            </group>
          ) : null}
          <mesh visible={false}>
            <sphereGeometry args={[hitRadius, 8, 8]} />
            <meshBasicMaterial />
          </mesh>
        </group>
      </group>
    </group>
  );
}

function OrbitPath({ body }: { body: CelestialBody }) {
  const object = useMemo(() => {
    const geometry = new THREE.BufferGeometry().setFromPoints(makeOrbitPoints(body.distance));
    const material = new THREE.LineBasicMaterial({
      color: body.trail,
      transparent: true,
      opacity: 0.28,
    });
    const loop = new THREE.LineLoop(geometry, material);
    loop.raycast = noopRaycast;
    return loop;
  }, [body.distance, body.trail]);

  useLayoutEffect(
    () => () => {
      object.geometry.dispose();
      (object.material as THREE.Material).dispose();
    },
    [object],
  );

  const inclination = (body.inclination * Math.PI) / 180;
  return (
    <group rotation={[inclination, 0, 0]}>
      <primitive object={object} />
    </group>
  );
}

function AsteroidBelt({ groupRef }: { groupRef: (node: THREE.Group | null) => void }) {
  const count = 420;
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const geometry = useMemo(() => new THREE.SphereGeometry(1, 6, 5), []);
  const material = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#7a756e",
        roughness: 1,
        metalness: 0.08,
      }),
    [],
  );

  useLayoutEffect(() => {
    const mesh = meshRef.current;
    if (!mesh) return;
    const dummy = new THREE.Object3D();
    for (let i = 0; i < count; i++) {
      const a = (i / count) * Math.PI * 2 + hash(i) * 0.4;
      const r = 29.4 + hash(i + 17) * 5.6;
      dummy.position.set(
        Math.cos(a) * r,
        (hash(i + 31) - 0.5) * 0.7,
        Math.sin(a) * r,
      );
      const s = 0.03 + hash(i + 53) * 0.09;
      dummy.scale.set(s, s * (0.7 + hash(i + 71) * 0.6), s);
      dummy.rotation.set(hash(i + 3) * 6, hash(i + 5) * 6, hash(i + 7) * 6);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
    return () => {
      geometry.dispose();
      material.dispose();
    };
  }, [count, geometry, material]);

  return (
    <group ref={groupRef}>
      <instancedMesh ref={meshRef} args={[geometry, material, count]} raycast={noopRaycast} />
    </group>
  );
}

function hash(i: number): number {
  const n = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return n - Math.floor(n);
}

function System() {
  const orbitRefs = useRef<Partial<Record<BodyId, THREE.Group | null>>>({});
  const spinRefs = useRef<Partial<Record<BodyId, THREE.Group | null>>>({});
  const moonRef = useRef<THREE.Group | null>(null);
  const cloudRef = useRef<THREE.Mesh | null>(null);
  const beltRef = useRef<THREE.Group | null>(null);
  const acc = useRef(0);
  const showOrbits = useSim((s) => s.showOrbits);
  const showTrails = useSim((s) => s.showTrails);

  useFrame((_, delta) => {
    const d = Math.min(delta, 0.1);
    const { paused, speed, setSimDays } = useSim.getState();
    if (!paused) {
      simClock.days += d * speed * DAYS_PER_REAL_SECOND;
    }
    const days = simClock.days;
    const years = days / 365.25;

    for (const body of PLANETS) {
      const orbit = orbitRefs.current[body.id];
      if (orbit) {
        orbit.rotation.y = (years / body.orbitYears) * Math.PI * 2 + body.phase;
      }
      const spin = spinRefs.current[body.id];
      if (spin && !paused) {
        const dir = body.dayLength < 0 ? -1 : 1;
        const period = Math.max(Math.abs(body.dayLength), 0.28);
        spin.rotation.y += (dir * d * speed * Math.PI * 2) / (period * EARTH_SPIN_SECONDS);
      }
    }

    if (moonRef.current) {
      moonRef.current.rotation.y = (days / 27.3) * Math.PI * 2;
    }
    if (cloudRef.current && !paused) {
      cloudRef.current.rotation.y += d * speed * 0.1;
    }
    if (beltRef.current) {
      beltRef.current.rotation.y = years * 0.18;
    }

    acc.current += d;
    if (acc.current > 0.25) {
      acc.current = 0;
      setSimDays(days);
    }
  });

  return (
    <group>
      <Sun />
      {showOrbits
        ? PLANETS.map((body) => <OrbitPath key={`orbit-${body.id}`} body={body} />)
        : null}
      {showTrails
        ? PLANETS.map((body) => (
            <WakeTrail key={`trail-${body.id}`} bodyId={body.id} color={body.trail} />
          ))
        : null}
      {PLANETS.map((body) => (
        <Planet
          key={body.id}
          body={body}
          orbitRef={(node) => {
            orbitRefs.current[body.id] = node;
          }}
          spinRef={(node) => {
            spinRefs.current[body.id] = node;
          }}
          moonRef={body.hasMoon ? (node) => { moonRef.current = node; } : undefined}
          cloudRef={body.hasClouds ? (node) => { cloudRef.current = node; } : undefined}
        />
      ))}
      <AsteroidBelt groupRef={(node) => { beltRef.current = node; }} />
    </group>
  );
}

function SceneLights() {
  return (
    <>
      <color attach="background" args={["#07080b"]} />
      <fog attach="fog" args={["#07080b", 170, 340]} />
      <ambientLight intensity={0.07} color="#cdd6e4" />
      <hemisphereLight args={["#1a2438", "#09090c", 0.22]} />
      <Starfield />
    </>
  );
}

export function SolarScene() {
  return (
    <Canvas
      className="touch-none h-full w-full"
      camera={{ position: [0, 46, 118], fov: 42, near: 0.1, far: 400 }}
      dpr={[1, 1.75]}
      gl={{
        antialias: true,
        alpha: false,
        powerPreference: "high-performance",
      }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.08;
        gl.setClearColor("#07080b", 1);
      }}
      onPointerMissed={() => {
        useSim.getState().clearFocus();
      }}
    >
      <SceneLights />
      <System />
      <CameraRig />
      <OrbitControls
        makeDefault
        enableDamping
        dampingFactor={0.08}
        rotateSpeed={0.55}
        zoomSpeed={0.72}
        panSpeed={0.4}
        minPolarAngle={0.18}
        maxPolarAngle={Math.PI - 0.18}
        enablePan
      />
    </Canvas>
  );
}
