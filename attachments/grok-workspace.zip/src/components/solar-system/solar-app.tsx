import { Overlay } from "./overlay";
import { SolarScene } from "./scene";

export default function SolarApp() {
  return (
    <main className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <h1 className="sr-only">Órbita — explorador del sistema solar</h1>
      <SolarScene />
      <Overlay />
    </main>
  );
}
