export type BodyKind = "star" | "planet";

export type BodyId =
  | "sun"
  | "mercury"
  | "venus"
  | "earth"
  | "mars"
  | "jupiter"
  | "saturn"
  | "uranus"
  | "neptune";

export type TextureKind =
  | "sun"
  | "rocky"
  | "venus"
  | "earth"
  | "mars"
  | "gas"
  | "ice-giant";

export type CelestialBody = {
  id: BodyId;
  name: string;
  kind: BodyKind;
  subtitle: string;
  /** Visual radius in scene units. */
  radius: number;
  /** Visual orbital radius. */
  distance: number;
  /** Real semi-major axis, AU. */
  au: number;
  /** Sidereal orbit in Earth years. */
  orbitYears: number;
  /** Axial rotation in Earth days. Negative = retrograde. */
  dayLength: number;
  /** Axial tilt, degrees. */
  tilt: number;
  /** Orbital inclination, degrees. */
  inclination: number;
  moons: number;
  diameterKm: number;
  /** Starting mean anomaly, radians. */
  phase: number;
  /** Surface / UI swatch. */
  swatch: string;
  trail: string;
  texture: TextureKind;
  hasRings?: boolean;
  hasClouds?: boolean;
  hasMoon?: boolean;
  description: string;
  facts: { label: string; value: string }[];
};

export const YEAR_SECONDS = 24;
export const DAYS_PER_REAL_SECOND = 365.25 / YEAR_SECONDS;
/** Earth completes one spin in this many real seconds at 1×. */
export const EARTH_SPIN_SECONDS = 5;

export const BODIES: CelestialBody[] = [
  {
    id: "sun",
    name: "Sol",
    kind: "star",
    subtitle: "Estrella enana G2V",
    radius: 4.6,
    distance: 0,
    au: 0,
    orbitYears: 0,
    dayLength: 25.05,
    tilt: 7.25,
    inclination: 0,
    moons: 0,
    diameterKm: 1_392_700,
    phase: 0,
    swatch: "#f0c27a",
    trail: "#f0c27a",
    texture: "sun",
    description:
      "El corazón gravitatorio del sistema. Una esfera de hidrógeno y helio que fusiona su núcleo a 15 millones de grados y arrastra a todos los planetas.",
    facts: [
      { label: "Tipo", value: "Enana amarilla" },
      { label: "Edad", value: "4.600 Ma" },
      { label: "Masa", value: "1 M☉" },
      { label: "Temperatura", value: "5.772 K" },
    ],
  },
  {
    id: "mercury",
    name: "Mercurio",
    kind: "planet",
    subtitle: "Planeta terrestre",
    radius: 0.38,
    distance: 10.2,
    au: 0.39,
    orbitYears: 0.241,
    dayLength: 58.6,
    tilt: 0.03,
    inclination: 7.0,
    moons: 0,
    diameterKm: 4_879,
    phase: 0.7,
    swatch: "#b9b3aa",
    trail: "#c9c2b8",
    texture: "rocky",
    description:
      "El más cercano al Sol y el más marcado por cráteres. Entre el día abrasador y la noche gélida hay más de 600 °C de diferencia.",
    facts: [
      { label: "Distancia", value: "0,39 UA" },
      { label: "Órbita", value: "88 días" },
      { label: "Día", value: "59 días" },
      { label: "Lunas", value: "Ninguna" },
    ],
  },
  {
    id: "venus",
    name: "Venus",
    kind: "planet",
    subtitle: "Planeta terrestre",
    radius: 0.72,
    distance: 14.4,
    au: 0.72,
    orbitYears: 0.615,
    dayLength: -243,
    tilt: 177.4,
    inclination: 3.4,
    moons: 0,
    diameterKm: 12_104,
    phase: 2.4,
    swatch: "#e4d0a8",
    trail: "#edd9b0",
    texture: "venus",
    description:
      "Gemelo de la Tierra en tamaño, cubierto por nubes de ácido sulfúrico. Gira al revés y un día suyo dura más que su año.",
    facts: [
      { label: "Distancia", value: "0,72 UA" },
      { label: "Órbita", value: "225 días" },
      { label: "Día", value: "243 días ↺" },
      { label: "Atmósfera", value: "CO₂ denso" },
    ],
  },
  {
    id: "earth",
    name: "Tierra",
    kind: "planet",
    subtitle: "Planeta terrestre",
    radius: 0.78,
    distance: 19.2,
    au: 1,
    orbitYears: 1,
    dayLength: 1,
    tilt: 23.4,
    inclination: 0,
    moons: 1,
    diameterKm: 12_756,
    phase: 4.1,
    swatch: "#6ea4d8",
    trail: "#8ec0ee",
    texture: "earth",
    hasClouds: true,
    hasMoon: true,
    description:
      "El único mundo conocido con vida. Océanos líquidos, una luna estable y un campo magnético que desvía el viento solar.",
    facts: [
      { label: "Distancia", value: "1 UA" },
      { label: "Órbita", value: "365,25 días" },
      { label: "Día", value: "23 h 56 min" },
      { label: "Lunas", value: "1 · Luna" },
    ],
  },
  {
    id: "mars",
    name: "Marte",
    kind: "planet",
    subtitle: "Planeta terrestre",
    radius: 0.52,
    distance: 24.6,
    au: 1.52,
    orbitYears: 1.881,
    dayLength: 1.03,
    tilt: 25.2,
    inclination: 1.85,
    moons: 2,
    diameterKm: 6_792,
    phase: 1.2,
    swatch: "#c56a48",
    trail: "#d98a68",
    texture: "mars",
    description:
      "El planeta rojo. Valles secos, casquetes polares de hielo y el volcán más alto del sistema solar, Olympus Mons.",
    facts: [
      { label: "Distancia", value: "1,52 UA" },
      { label: "Órbita", value: "687 días" },
      { label: "Día", value: "24 h 37 min" },
      { label: "Lunas", value: "2 · Fobos, Deimos" },
    ],
  },
  {
    id: "jupiter",
    name: "Júpiter",
    kind: "planet",
    subtitle: "Gigante gaseoso",
    radius: 2.35,
    distance: 36.5,
    au: 5.2,
    orbitYears: 11.86,
    dayLength: 0.41,
    tilt: 3.1,
    inclination: 1.3,
    moons: 95,
    diameterKm: 142_984,
    phase: 3.6,
    swatch: "#d4b48a",
    trail: "#e0c49a",
    texture: "gas",
    description:
      "El mayor de todos. Su Gran Mancha Roja es una tormenta más ancha que la Tierra, activa desde hace siglos.",
    facts: [
      { label: "Distancia", value: "5,20 UA" },
      { label: "Órbita", value: "11,9 años" },
      { label: "Día", value: "9 h 56 min" },
      { label: "Lunas", value: "95" },
    ],
  },
  {
    id: "saturn",
    name: "Saturno",
    kind: "planet",
    subtitle: "Gigante gaseoso",
    radius: 2.02,
    distance: 50.5,
    au: 9.58,
    orbitYears: 29.46,
    dayLength: 0.45,
    tilt: 26.7,
    inclination: 2.49,
    moons: 146,
    diameterKm: 120_536,
    phase: 5.5,
    swatch: "#e6d3a4",
    trail: "#f0dfb4",
    texture: "gas",
    hasRings: true,
    description:
      "Ligero como para flotar en agua, si existiera un océano tan grande. Sus anillos son hielo y polvo en órbita milimétrica.",
    facts: [
      { label: "Distancia", value: "9,58 UA" },
      { label: "Órbita", value: "29,5 años" },
      { label: "Día", value: "10 h 33 min" },
      { label: "Anillos", value: "Hasta 282.000 km" },
    ],
  },
  {
    id: "uranus",
    name: "Urano",
    kind: "planet",
    subtitle: "Gigante de hielo",
    radius: 1.22,
    distance: 63.5,
    au: 19.2,
    orbitYears: 84.01,
    dayLength: -0.72,
    tilt: 97.8,
    inclination: 0.77,
    moons: 28,
    diameterKm: 51_118,
    phase: 2.2,
    swatch: "#9fd4d8",
    trail: "#b7e4e6",
    texture: "ice-giant",
    description:
      "Rueda de lado: su eje está tumbado casi 98°. Un mundo frío de hielos de agua, amoníaco y metano que tiñe la atmósfera de cian.",
    facts: [
      { label: "Distancia", value: "19,2 UA" },
      { label: "Órbita", value: "84 años" },
      { label: "Día", value: "17 h 14 min ↺" },
      { label: "Inclinación", value: "97,8°" },
    ],
  },
  {
    id: "neptune",
    name: "Neptuno",
    kind: "planet",
    subtitle: "Gigante de hielo",
    radius: 1.18,
    distance: 76,
    au: 30.05,
    orbitYears: 164.8,
    dayLength: 0.67,
    tilt: 28.3,
    inclination: 1.77,
    moons: 16,
    diameterKm: 49_528,
    phase: 0.9,
    swatch: "#4a7fd4",
    trail: "#6a99e4",
    texture: "ice-giant",
    description:
      "El más lejano. Vientos supersónicos y un azul profundo por el metano. Fue predicho con matemáticas antes de ser visto.",
    facts: [
      { label: "Distancia", value: "30,1 UA" },
      { label: "Órbita", value: "165 años" },
      { label: "Día", value: "16 h 6 min" },
      { label: "Lunas", value: "16 · Tritón" },
    ],
  },
];

export const PLANETS = BODIES.filter((b) => b.kind === "planet");
export const SUN = BODIES[0]!;

export const BODY_BY_ID: Record<BodyId, CelestialBody> = BODIES.reduce(
  (acc, body) => {
    acc[body.id] = body;
    return acc;
  },
  {} as Record<BodyId, CelestialBody>,
);

export function formatSimTime(days: number): { year: string; day: string } {
  const year = days / 365.25;
  const dayOfYear = Math.floor(days % 365.25) + 1;
  return {
    year: year.toFixed(2),
    day: String(dayOfYear),
  };
}

export function speedFromSlider(t: number): number {
  const min = 0.25;
  const max = 50;
  return min * Math.pow(max / min, t);
}

export function sliderFromSpeed(speed: number): number {
  const min = 0.25;
  const max = 50;
  const clamped = Math.min(max, Math.max(min, speed));
  return Math.log(clamped / min) / Math.log(max / min);
}

export function formatSpeed(speed: number): string {
  if (speed >= 10) return `${Math.round(speed)}×`;
  if (speed >= 1) return `${speed.toFixed(1)}×`;
  return `${speed.toFixed(2)}×`;
}
