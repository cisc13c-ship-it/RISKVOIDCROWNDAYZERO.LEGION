import { create } from "zustand";
import type { BodyId } from "./bodies";

const STORAGE_KEY = "orbita-sim-v1";

type Persisted = {
  speed: number;
  showLabels: boolean;
  showOrbits: boolean;
  showTrails: boolean;
};

function load(): Partial<Persisted> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Partial<Persisted>;
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

type SimState = {
  paused: boolean;
  speed: number;
  selectedId: BodyId | null;
  showLabels: boolean;
  showOrbits: boolean;
  showTrails: boolean;
  simDays: number;
  focusNonce: number;
  setPaused: (value: boolean) => void;
  togglePaused: () => void;
  setSpeed: (value: number) => void;
  focus: (id: BodyId | null) => void;
  clearFocus: () => void;
  setShowLabels: (value: boolean) => void;
  setShowOrbits: (value: boolean) => void;
  setShowTrails: (value: boolean) => void;
  setSimDays: (value: number) => void;
};

const persisted = load();

export const useSim = create<SimState>((set, get) => {
  const persist = () => {
    if (typeof window === "undefined") return;
    const { speed, showLabels, showOrbits, showTrails } = get();
    window.localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ speed, showLabels, showOrbits, showTrails } satisfies Persisted),
    );
  };

  return {
    paused: false,
    speed: typeof persisted.speed === "number" ? persisted.speed : 1,
    selectedId: null,
    showLabels: persisted.showLabels ?? true,
    showOrbits: persisted.showOrbits ?? true,
    showTrails: persisted.showTrails ?? true,
    simDays: 0,
    focusNonce: 0,
    setPaused: (value) => set({ paused: value }),
    togglePaused: () => set({ paused: !get().paused }),
    setSpeed: (value) => {
      set({ speed: value });
      persist();
    },
    focus: (id) =>
      set((state) => ({
        selectedId: id,
        focusNonce: state.focusNonce + 1,
      })),
    clearFocus: () => {
      if (get().selectedId === null) return;
      set((state) => ({ selectedId: null, focusNonce: state.focusNonce + 1 }));
    },
    setShowLabels: (value) => {
      set({ showLabels: value });
      persist();
    },
    setShowOrbits: (value) => {
      set({ showOrbits: value });
      persist();
    },
    setShowTrails: (value) => {
      set({ showTrails: value });
      persist();
    },
    setSimDays: (value) => set({ simDays: value }),
  };
});
