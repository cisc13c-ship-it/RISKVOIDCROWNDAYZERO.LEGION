import * as THREE from "three";
import type { CelestialBody, TextureKind } from "./bodies";

function hash(ix: number, iy: number, iz: number): number {
  const n = Math.sin(ix * 127.1 + iy * 311.7 + iz * 74.7) * 43758.5453;
  return n - Math.floor(n);
}

function noise3(x: number, y: number, z: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const iz = Math.floor(z);
  const fx = x - ix;
  const fy = y - iy;
  const fz = z - iz;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const uz = fz * fz * (3 - 2 * fz);
  const n000 = hash(ix, iy, iz);
  const n100 = hash(ix + 1, iy, iz);
  const n010 = hash(ix, iy + 1, iz);
  const n110 = hash(ix + 1, iy + 1, iz);
  const n001 = hash(ix, iy, iz + 1);
  const n101 = hash(ix + 1, iy, iz + 1);
  const n011 = hash(ix, iy + 1, iz + 1);
  const n111 = hash(ix + 1, iy + 1, iz + 1);
  const nx00 = n000 * (1 - ux) + n100 * ux;
  const nx10 = n010 * (1 - ux) + n110 * ux;
  const nx01 = n001 * (1 - ux) + n101 * ux;
  const nx11 = n011 * (1 - ux) + n111 * ux;
  const nxy0 = nx00 * (1 - uy) + nx10 * uy;
  const nxy1 = nx01 * (1 - uy) + nx11 * uy;
  return nxy0 * (1 - uz) + nxy1 * uz;
}

function fbm(x: number, y: number, z: number, octaves = 4): number {
  let value = 0;
  let amp = 0.5;
  let freq = 1;
  for (let i = 0; i < octaves; i++) {
    value += amp * noise3(x * freq, y * freq, z * freq);
    amp *= 0.5;
    freq *= 2;
  }
  return value;
}

function wrapNoise(lon: number, lat: number, scale: number, seed = 0): number {
  const x = Math.cos(lon) * Math.cos(lat) * scale;
  const y = Math.sin(lat) * scale;
  const z = Math.sin(lon) * Math.cos(lat) * scale + seed * 17.2;
  return fbm(x, y, z);
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function mix(
  a: [number, number, number],
  b: [number, number, number],
  t: number,
): [number, number, number] {
  return [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
}

function toTexture(canvas: HTMLCanvasElement): THREE.CanvasTexture {
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.anisotropy = 8;
  texture.needsUpdate = true;
  return texture;
}

function makeCanvas(width: number, height: number): {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  data: Uint8ClampedArray;
  put: () => void;
} {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas 2D unavailable");
  const image = ctx.createImageData(width, height);
  return {
    canvas,
    ctx,
    data: image.data,
    put: () => ctx.putImageData(image, 0, 0),
  };
}

function setPx(
  data: Uint8ClampedArray,
  w: number,
  x: number,
  y: number,
  r: number,
  g: number,
  b: number,
  a = 255,
) {
  const i = (y * w + x) * 4;
  data[i] = r;
  data[i + 1] = g;
  data[i + 2] = b;
  data[i + 3] = a;
}

function paintRocky(
  data: Uint8ClampedArray,
  w: number,
  h: number,
  base: [number, number, number],
  dark: [number, number, number],
  craterDensity: number,
) {
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const lon = (x / w) * Math.PI * 2;
      const lat = (y / h) * Math.PI - Math.PI / 2;
      const n = wrapNoise(lon, lat, 4.2, 1);
      const n2 = wrapNoise(lon, lat, 11, 4);
      let t = n * 0.7 + n2 * 0.3;
      const crater = wrapNoise(lon, lat, 18, 9);
      if (crater > craterDensity) {
        t -= (crater - craterDensity) * 1.8;
      }
      const c = mix(dark, base, Math.min(1, Math.max(0, t)));
      setPx(data, w, x, y, c[0], c[1], c[2]);
    }
  }
}

function paintEarth(data: Uint8ClampedArray, w: number, h: number) {
  const oceanDeep: [number, number, number] = [8, 48, 108];
  const ocean: [number, number, number] = [24, 96, 168];
  const land: [number, number, number] = [42, 118, 58];
  const desert: [number, number, number] = [168, 148, 86];
  const ice: [number, number, number] = [236, 240, 244];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const lon = (x / w) * Math.PI * 2;
      const lat = (y / h) * Math.PI - Math.PI / 2;
      const n = wrapNoise(lon, lat, 2.6, 2);
      const ridges = wrapNoise(lon, lat, 7.5, 6);
      const polar = Math.pow(Math.abs(Math.sin(lat)), 6);
      let c: [number, number, number];
      if (polar > 0.72 || (polar > 0.45 && n > 0.46)) {
        c = mix(ocean, ice, Math.min(1, polar + 0.2));
      } else if (n > 0.57) {
        const arid = wrapNoise(lon, lat + 0.4, 3.2, 8);
        c = mix(land, desert, Math.max(0, arid - 0.45) * 1.6);
        c = mix(c, [32, 78, 44], ridges * 0.25);
      } else {
        c = mix(oceanDeep, ocean, n * 1.4);
      }
      setPx(data, w, x, y, c[0], c[1], c[2]);
    }
  }
}

function paintMars(data: Uint8ClampedArray, w: number, h: number) {
  const rust: [number, number, number] = [168, 72, 42];
  const dark: [number, number, number] = [92, 42, 28];
  const dust: [number, number, number] = [196, 118, 72];
  const ice: [number, number, number] = [232, 228, 220];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const lon = (x / w) * Math.PI * 2;
      const lat = (y / h) * Math.PI - Math.PI / 2;
      const n = wrapNoise(lon, lat, 3.4, 3);
      const polar = Math.pow(Math.abs(Math.sin(lat)), 8);
      let c = mix(dark, rust, n);
      c = mix(c, dust, wrapNoise(lon, lat, 8, 5) * 0.45);
      if (polar > 0.55) c = mix(c, ice, (polar - 0.55) * 3);
      setPx(data, w, x, y, c[0], c[1], c[2]);
    }
  }
}

function paintVenus(data: Uint8ClampedArray, w: number, h: number) {
  const pale: [number, number, number] = [228, 206, 158];
  const swirl: [number, number, number] = [196, 168, 118];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const lon = (x / w) * Math.PI * 2 + (y / h) * 1.4;
      const lat = (y / h) * Math.PI - Math.PI / 2;
      const bands = 0.5 + 0.5 * Math.sin(lat * 10 + wrapNoise(lon, lat, 2, 1) * 4);
      const n = wrapNoise(lon, lat, 5, 2);
      const c = mix(pale, swirl, bands * 0.55 + n * 0.25);
      setPx(data, w, x, y, c[0], c[1], c[2]);
    }
  }
}

function paintGas(
  data: Uint8ClampedArray,
  w: number,
  h: number,
  a: [number, number, number],
  b: [number, number, number],
  c: [number, number, number],
  storm?: { lat: number; lon: number; color: [number, number, number] },
) {
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const lon = (x / w) * Math.PI * 2;
      const lat = (y / h) * Math.PI - Math.PI / 2;
      const warp = wrapNoise(lon, lat, 2.2, 1) * 1.4;
      const bands = Math.sin(lat * 14 + warp * 3);
      const n = wrapNoise(lon * 0.4 + lat * 6, lat, 3.5, 4);
      let col = mix(a, b, 0.5 + 0.5 * bands);
      col = mix(col, c, n * 0.4);
      if (storm) {
        const dlon = lon - storm.lon;
        const dlat = lat - storm.lat;
        const d = Math.sqrt(dlon * dlon * 0.6 + dlat * dlat * 3.2);
        if (d < 0.28) {
          col = mix(col, storm.color, 1 - d / 0.28);
        }
      }
      setPx(data, w, x, y, col[0], col[1], col[2]);
    }
  }
}

function paintIceGiant(
  data: Uint8ClampedArray,
  w: number,
  h: number,
  base: [number, number, number],
  deep: [number, number, number],
) {
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const lon = (x / w) * Math.PI * 2;
      const lat = (y / h) * Math.PI - Math.PI / 2;
      const bands = 0.5 + 0.5 * Math.sin(lat * 6 + wrapNoise(lon, lat, 1.6, 2) * 2);
      const n = wrapNoise(lon, lat, 4, 7);
      const c = mix(deep, base, 0.35 + bands * 0.4 + n * 0.2);
      setPx(data, w, x, y, c[0], c[1], c[2]);
    }
  }
}

function paintSun(data: Uint8ClampedArray, w: number, h: number) {
  const core: [number, number, number] = [255, 236, 196];
  const limb: [number, number, number] = [255, 164, 64];
  const spot: [number, number, number] = [176, 82, 28];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const lon = (x / w) * Math.PI * 2;
      const lat = (y / h) * Math.PI - Math.PI / 2;
      const gran = wrapNoise(lon, lat, 14, 1);
      const n = wrapNoise(lon, lat, 5, 3);
      let c = mix(limb, core, 0.35 + gran * 0.65);
      if (n > 0.72) c = mix(c, spot, (n - 0.72) * 3);
      setPx(data, w, x, y, c[0], c[1], c[2]);
    }
  }
}

export function createBodyTexture(kind: TextureKind, id: string): THREE.CanvasTexture {
  const w = 512;
  const h = 256;
  const { canvas, data, put } = makeCanvas(w, h);

  if (kind === "sun") paintSun(data, w, h);
  else if (kind === "earth") paintEarth(data, w, h);
  else if (kind === "mars") paintMars(data, w, h);
  else if (kind === "venus") paintVenus(data, w, h);
  else if (kind === "rocky") {
    paintRocky(data, w, h, [186, 178, 168], [92, 86, 80], 0.78);
  } else if (kind === "gas") {
    if (id === "jupiter") {
      paintGas(
        data,
        w,
        h,
        [214, 176, 128],
        [168, 118, 78],
        [236, 214, 176],
        { lat: 0.22, lon: 3.4, color: [176, 72, 48] },
      );
    } else {
      paintGas(data, w, h, [232, 210, 160], [196, 168, 118], [244, 228, 186]);
    }
  } else if (id === "neptune") {
    paintIceGiant(data, w, h, [74, 122, 210], [22, 48, 120]);
  } else {
    paintIceGiant(data, w, h, [154, 212, 214], [48, 110, 126]);
  }

  put();
  const texture = toTexture(canvas);
  texture.name = `body-${id}`;
  return texture;
}

export function createCloudTexture(): THREE.CanvasTexture {
  const w = 512;
  const h = 256;
  const { canvas, data, put } = makeCanvas(w, h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const lon = (x / w) * Math.PI * 2;
      const lat = (y / h) * Math.PI - Math.PI / 2;
      const n = wrapNoise(lon, lat, 3.8, 11);
      const n2 = wrapNoise(lon, lat, 9, 14);
      const v = (n - 0.48) * 2.4 + n2 * 0.2;
      const a = Math.min(255, Math.max(0, v * 180));
      setPx(data, w, x, y, 236, 242, 248, a);
    }
  }
  put();
  const texture = toTexture(canvas);
  texture.name = "clouds";
  return texture;
}

export function createRingTexture(): THREE.CanvasTexture {
  const w = 4;
  const h = 512;
  const { canvas, data, put } = makeCanvas(w, h);
  for (let y = 0; y < h; y++) {
    const t = y / (h - 1);
    let alpha = 1;
    if (t < 0.04 || t > 0.98) alpha = 0;
    else if (t > 0.58 && t < 0.66) alpha = 0.05;
    else if (t > 0.78 && t < 0.82) alpha = 0.15;
    else alpha = 0.35 + 0.45 * (0.5 + 0.5 * Math.sin(t * 80));
    const shade = 180 + Math.floor(40 * Math.sin(t * 40));
    for (let x = 0; x < w; x++) {
      setPx(data, w, x, y, shade, shade - 12, shade - 28, Math.floor(alpha * 255));
    }
  }
  put();
  const texture = toTexture(canvas);
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.name = "saturn-rings";
  return texture;
}

export function createMoonTexture(): THREE.CanvasTexture {
  const w = 256;
  const h = 128;
  const { canvas, data, put } = makeCanvas(w, h);
  paintRocky(data, w, h, [176, 174, 168], [78, 76, 72], 0.7);
  put();
  return toTexture(canvas);
}

export function disposeTexture(texture: THREE.Texture | null | undefined) {
  texture?.dispose();
}

export function bodyRoughness(body: CelestialBody): number {
  if (body.texture === "gas" || body.texture === "ice-giant") return 0.55;
  if (body.texture === "venus") return 0.7;
  if (body.texture === "earth") return 0.62;
  return 0.86;
}
