import type { Object3D } from "three";
import type { BodyId } from "./bodies";

export const bodyAnchors = new Map<BodyId, Object3D>();
export const labelNodes = new Map<BodyId, HTMLElement>();

export const simClock = {
  days: 0,
};
