class World:
    def __init__(self, state):
        self.state = state

    @classmethod
    def demo(cls):
        return cls({
            "turn": 0, "resources": 100, "stability": 100,
            "population": 1000, "territory": 3, "history": []
        })

    def snapshot(self):
        return dict(self.state)
