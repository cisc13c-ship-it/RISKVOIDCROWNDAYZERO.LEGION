class Director:
    def __init__(self, world):
        self.world = world

    def choose_event(self, turn):
        s = self.world.state
        if s["stability"] < 45:
            return {"type": "RECOVERY", "reason": "stability_low"}
        if s["resources"] < 50:
            return {"type": "TRADE_BOOM", "reason": "resources_low"}

        cycle = ["ASTEROID", "DROUGHT", "TRADE_BOOM", "REBELLION"]
        return {"type": cycle[(turn - 1) % len(cycle)], "reason": "world_pressure"}
