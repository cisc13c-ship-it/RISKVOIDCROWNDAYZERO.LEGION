# Evolution boundary

Future loop:
OBSERVE → MAP → HYPOTHESIZE → EXPERIMENT → BREAK → MEASURE
→ COMPARE → LEARN → PROPOSE → SANDBOX → JUDGE → PROMOTE/ROLLBACK

Mutation promotion is intentionally NOT automatic in this first prototype.
