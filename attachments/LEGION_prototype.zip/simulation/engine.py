import hashlib, json, time

class Simulation:
    EFFECTS = {
        "ASTEROID": {"resources": -25, "stability": -20},
        "DROUGHT": {"resources": -15, "stability": -10},
        "TRADE_BOOM": {"resources": 20, "stability": 5},
        "REBELLION": {"resources": -10, "stability": -25},
        "RECOVERY": {"resources": 10, "stability": 15},
    }

    def __init__(self, world, ledger):
        self.world, self.ledger = world, ledger

    def apply(self, event):
        before = self.world.snapshot()
        self.world.state["turn"] += 1
        effect = self.EFFECTS[event["type"]]

        for key, delta in effect.items():
            self.world.state[key] += delta

        self.world.state["resources"] = max(0, self.world.state["resources"])
        self.world.state["stability"] = max(0, min(100, self.world.state["stability"]))

        after = self.world.snapshot()
        consequence = (
            f"{event['type']} alteró recursos "
            f"{effect.get('resources',0):+d} y estabilidad "
            f"{effect.get('stability',0):+d}"
        )

        raw = json.dumps({"event": event, "before": before, "after": after}, sort_keys=True)
        event_id = hashlib.sha256(raw.encode()).hexdigest()[:16]

        self.ledger.append({
            "timestamp": time.time(),
            "event_id": event_id,
            "event": event,
            "before": before,
            "consequence": consequence,
            "after": after
        })
        self.world.state["history"].append(event_id)
        return {"event_id": event_id, "consequence": consequence}
