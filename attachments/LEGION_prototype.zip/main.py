import json
from world.world import World
from simulation.engine import Simulation
from memory.ledger import EventLedger
from agents.director import Director
from testing.judge import Judge

def main():
    world = World.demo()
    ledger = EventLedger("memory/events.jsonl")
    simulation = Simulation(world, ledger)
    director = Director(world)
    judge = Judge()

    print("\n=== LEGIÓN — PROTOTIPO ===")
    print("Consequential World Experience\n")

    for turn in range(1, 6):
        event = director.choose_event(turn)
        result = simulation.apply(event)
        print(f"--- TURNO {turn} ---")
        print(f"EVENTO: {event['type']}")
        print(f"CONSECUENCIA: {result['consequence']}")
        print(f"ESTADO: recursos={world.state['resources']}, estabilidad={world.state['stability']}")
        print(f"MEMORIA: {result['event_id']}\n")

    verdict = judge.verify(world, ledger)
    print("=== JUEZ DE EVIDENCIA ===")
    print(json.dumps(verdict, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
