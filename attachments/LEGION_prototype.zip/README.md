# LEGIÓN Prototype
Consequential World Experience

Pipeline:
EVENT → CONSEQUENCE → STATE → MEMORY → NEW POSSIBILITY

Run:
python3 main.py
