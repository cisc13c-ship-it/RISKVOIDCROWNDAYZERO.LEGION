class Judge:
    def verify(self, world, ledger):
        records = ledger.read_all()
        checks = {
            "events_recorded": len(records) > 0,
            "state_changed": any(r["before"] != r["after"] for r in records),
            "causality_recorded": all("consequence" in r for r in records),
            "event_ids_present": all(r.get("event_id") for r in records),
            "world_bounds_valid": (
                world.state["resources"] >= 0
                and 0 <= world.state["stability"] <= 100
            ),
        }
        return {
            "status": "PASS" if all(checks.values()) else "FAIL",
            "checks": checks,
            "records": len(records)
        }
