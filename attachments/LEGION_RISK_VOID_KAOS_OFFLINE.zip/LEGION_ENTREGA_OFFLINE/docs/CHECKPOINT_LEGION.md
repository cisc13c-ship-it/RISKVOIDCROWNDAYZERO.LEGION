# OFFLINE COMPLETO
- three.min.js r128 embebido en jugar/
- RISK_VOID_KAOS_THEATER sin CDN
- HOLO y FUSION sin dependencias externas
- Audio: Web Audio API (sintetizado, offline)
