#!/data/data/com.termux/files/usr/bin/bash
HERE="$(cd "$(dirname "$0")" && pwd)"
F="$HERE/jugar/RISK_VOID_KAOS_THEATER.html"
if [ -f "$F" ]; then
  if command -v termux-open >/dev/null 2>&1; then termux-open "$F"
  elif command -v termux-open-url >/dev/null 2>&1; then termux-open-url "file://$F"
  else echo "Abre: $F"; fi
else
  echo "Falta jugar/RISK_VOID_KAOS_THEATER.html"
  exit 1
fi
