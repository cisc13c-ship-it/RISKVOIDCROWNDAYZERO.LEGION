#!/data/data/com.termux/files/usr/bin/bash
# LEGION AUTOINSTALL — no destruye originales
set -euo pipefail
HOME_DIR="${HOME:-/data/data/com.termux/files/home}"
SDCARD="/sdcard/Download"
HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME_DIR/RISK_ZERODAY_CANON"
STAMP=$(date +%Y%m%d_%H%M%S)

echo "╔══════════════════════════════════════════╗"
echo "║  LEGION AUTOINSTALL · RISK / VOID / KAOS ║"
echo "╚══════════════════════════════════════════╝"
echo "  origen: $HERE"
echo "  destino: $DEST"
echo

mkdir -p "$DEST/playable" "$HOME_DIR/reportes" "$HOME_DIR/respaldos_fusion" "$HOME_DIR/checkpoints_legion"

# copiar scripts
cp -f "$HERE/LEGION_MAESTRO_UNICO.sh" "$HOME_DIR/LEGION_MAESTRO_UNICO.sh" 2>/dev/null || true
cp -f "$HERE/LEGION_MAESTRO_UNICO.sh" "$DEST/LEGION_MAESTRO_UNICO.sh" 2>/dev/null || true
chmod +x "$HOME_DIR/LEGION_MAESTRO_UNICO.sh" "$DEST/LEGION_MAESTRO_UNICO.sh" 2>/dev/null || true

# copiar HTML jugables (solo copia)
if [ -d "$HERE/jugar" ]; then
  cp -f "$HERE/jugar/"* "$DEST/playable/" 2>/dev/null || true
  # index = teatro 3D offline
  if [ -f "$DEST/playable/RISK_VOID_KAOS_THEATER.html" ]; then
    cp -f "$DEST/playable/RISK_VOID_KAOS_THEATER.html" "$DEST/playable/index.html"
  fi
  # three.min.js debe acompañar al HTML (offline)
  if [ -f "$HERE/jugar/three.min.js" ]; then
    cp -f "$HERE/jugar/three.min.js" "$DEST/playable/three.min.js"
  fi
fi
fi

# espejo en Download si existe
if [ -d "$SDCARD" ]; then
  mkdir -p "$SDCARD/RISK_ZERODAY_CANON/playable"
  cp -f "$DEST/playable/"*.html "$SDCARD/RISK_ZERODAY_CANON/playable/" 2>/dev/null || true
  cp -f "$HERE/LEGION_MAESTRO_UNICO.sh" "$SDCARD/LEGION_MAESTRO_UNICO.sh" 2>/dev/null || true
fi

# JUGAR.sh
cat > "$DEST/JUGAR.sh" << 'JUGAR'
#!/data/data/com.termux/files/usr/bin/bash
DIR="$(cd "$(dirname "$0")/playable" && pwd)"
PORT="${PORT:-8001}"
echo "╔══════════════════════════════════════════╗"
echo "║  RISK ZERODAY · http://127.0.0.1:$PORT     ║"
echo "║  NO Ctrl+C — usa otra sesión para stop   ║"
echo "╚══════════════════════════════════════════╝"
echo "  Principal: RISK_VOID_KAOS_THEATER.html"
echo "  http://127.0.0.1:$PORT/RISK_VOID_KAOS_THEATER.html"
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock 2>/dev/null || true
if command -v termux-open-url >/dev/null 2>&1; then
  (sleep 1; termux-open-url "http://127.0.0.1:$PORT/RISK_VOID_KAOS_THEATER.html") &
fi
cd "$DIR"
exec python3 -m http.server "$PORT" 2>/dev/null || exec python -m http.server "$PORT"
JUGAR
chmod +x "$DEST/JUGAR.sh"

# JUGAR_DIRECTO (abre archivo sin servidor)
cat > "$DEST/JUGAR_DIRECTO.sh" << 'DIR'
#!/data/data/com.termux/files/usr/bin/bash
F="$HOME/RISK_ZERODAY_CANON/playable/RISK_VOID_KAOS_THEATER.html"
if [ ! -f "$F" ]; then F="$(dirname "$0")/playable/RISK_VOID_KAOS_THEATER.html"; fi
if [ -f "$F" ]; then
  echo "Abriendo $F"
  if command -v termux-open >/dev/null 2>&1; then termux-open "$F"
  elif command -v termux-open-url >/dev/null 2>&1; then termux-open-url "file://$F"
  else echo "Abre manualmente: $F"; fi
else
  echo "No encontrado: RISK_VOID_KAOS_THEATER.html"
  exit 1
fi
DIR
chmod +x "$DEST/JUGAR_DIRECTO.sh"

# reporte
{
  echo "AUTOINSTALL $STAMP"
  echo "dest=$DEST"
  ls -la "$DEST/playable" 2>/dev/null || true
} > "$HOME_DIR/reportes/autoinstall_$STAMP.txt" 2>/dev/null || true

echo
echo "[OK] Instalado en $DEST"
echo
echo "  Jugar con servidor:"
echo "    bash $DEST/JUGAR.sh"
echo
echo "  Jugar SIN servidor (recomendado si Ctrl+C te mata todo):"
echo "    bash $DEST/JUGAR_DIRECTO.sh"
echo
echo "  Maestro completo:"
echo "    bash $HOME_DIR/LEGION_MAESTRO_UNICO.sh servir"
echo

# lanzar directo por defecto
if [ "${1:-}" = "nolaunch" ]; then
  exit 0
fi
echo "Lanzando JUGAR_DIRECTO en 2s..."
sleep 2
bash "$DEST/JUGAR_DIRECTO.sh" || bash "$DEST/JUGAR.sh"
