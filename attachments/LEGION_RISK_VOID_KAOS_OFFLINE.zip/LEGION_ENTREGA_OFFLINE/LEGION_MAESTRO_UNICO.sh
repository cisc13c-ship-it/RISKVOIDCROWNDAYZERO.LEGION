#!/data/data/com.termux/files/usr/bin/bash
# ═══════════════════════════════════════════════════════════
# LEGION MAESTRO ÚNICO — RISK ZERODAY / VOIDCROWN
# Base: grok-workspace · Protocolo: no destruir originales
# Uso: bash LEGION_MAESTRO_UNICO.sh
#      bash LEGION_MAESTRO_UNICO.sh jugar|directo|diag|servir|checkpoint
# ═══════════════════════════════════════════════════════════
# v1.1 — integración de mejoras SIN quitar capacidades v1.0
set -euo pipefail

VERSION="1.1.0-legion"
PORT="${PORT:-8001}"
HOME_DIR="${HOME:-/data/data/com.termux/files/home}"
SDCARD="/sdcard/Download"
SDCARD2="/storage/emulated/0/Download"
WORK_NAME="RISK_ZERODAY_CANON"
WORK="$HOME_DIR/$WORK_NAME"
REPORT_DIR="$HOME_DIR/reportes"
BACKUP_DIR="$HOME_DIR/respaldos_fusion"
CHECKPOINT_DIR="$HOME_DIR/checkpoints_legion"
STAMP=$(date +%Y%m%d_%H%M%S)
PIDFILE="$HOME_DIR/.legion_http_${PORT}.pid"
LOGFILE="$HOME_DIR/.legion_http_${PORT}.log"

# ── colores ──
R='\033[0;31m'; G='\033[0;32m'; C='\033[0;36m'; Y='\033[1;33m'; B='\033[1;37m'; N='\033[0m'
ok()   { echo -e "${G}[OK]${N} $*"; }
warn() { echo -e "${Y}[!]${N} $*"; }
err()  { echo -e "${R}[X]${N} $*"; }
info() { echo -e "${C}[·]${N} $*"; }
title(){ echo -e "${B}$*${N}"; }

banner() {
  clear 2>/dev/null || true
  echo -e "${C}"
  cat << 'EOF'
╔══════════════════════════════════════════════════════════╗
║  LEGION MAESTRO ÚNICO · RISK ZERODAY                     ║
║  Base canónica · Absorción segura · Sin destruir         ║
║  v1.1 — mejoras integradas · originales intactos         ║
╚══════════════════════════════════════════════════════════╝
EOF
  echo -e "${N}"
  echo "  v$VERSION  ·  nodo: $(hostname 2>/dev/null || echo termux)  ·  $STAMP"
  echo
}

# ── 1. Entorno ──
detect_env() {
  if [ -d "/data/data/com.termux" ] || [ -n "${TERMUX_VERSION:-}" ]; then
    ENV="termux"
    ok "Entorno: Termux / Android"
  else
    ENV="linux"
    ok "Entorno: Linux / desktop"
  fi
  mkdir -p "$REPORT_DIR" "$BACKUP_DIR" "$CHECKPOINT_DIR" 2>/dev/null || true
}

# ── 2. Protocolo LEGION (solo lectura) ──
protocol_check() {
  info "Protocolo: no destruir originales · solo copia segura"
  if [ -d "$HOME_DIR/legion-core" ]; then ok "legion-core presente"; else warn "legion-core no encontrado (opcional)"; fi
  if [ -d "$HOME_DIR/reportes" ]; then ok "reportes/ OK"; fi
  if [ -d "$HOME_DIR/NUCLEO_MASTER" ] || [ -d "$SDCARD/NUCLEO_CISC_V10" ]; then ok "Núcleo CISC detectado"; else warn "NUCLEO_CISC no visible (sigue)"; fi
  # no tocar NUCLEO ni legion-core nunca
  export LEGION_SAFE=1
}

# ── 2b. Checkpoint (NUEVO, no quita nada) ──
checkpoint() {
  info "Checkpoint seguro → $CHECKPOINT_DIR"
  local dest="$CHECKPOINT_DIR/ckpt_$STAMP"
  mkdir -p "$dest"
  # solo metadatos + lista; no mueve juegos
  {
    echo "stamp=$STAMP"
    echo "work=$WORK"
    date
    echo "--- playable ---"
    ls -la "$WORK/playable" 2>/dev/null || echo "(vacío)"
    echo "--- download risk/void/legion ---"
    ls -la "$SDCARD"/*RISK* "$SDCARD"/*VOID* "$SDCARD"/*LEGION* "$SDCARD"/*grok* 2>/dev/null || true
  } > "$dest/snapshot.txt" 2>/dev/null || true
  # copiar script actual si existe
  if [ -f "$0" ] && [ -r "$0" ]; then
    cp -n "$0" "$dest/LEGION_MAESTRO_UNICO.sh" 2>/dev/null || cp "$0" "$dest/LEGION_MAESTRO_UNICO.sh" 2>/dev/null || true
  fi
  ok "Checkpoint: $dest"
}

# ── 3. Buscar donantes y base ──
find_zips() {
  info "Buscando ZIPs en rutas típicas..."
  SEARCH_PATHS=(
    "$SDCARD" "$SDCARD2"
    "$HOME_DIR/Downloads" "$HOME_DIR/downloads" "$HOME_DIR/storage/downloads"
    "$HOME_DIR" "$PWD"
  )
  FOUND_WORKSPACE=""
  FOUND_OMEGA=""
  FOUND_HTML=""
  FOUND_MAESTRO_ZIP=""

  for p in "${SEARCH_PATHS[@]}"; do
    [ -d "$p" ] || continue
    while IFS= read -r f; do
      [ -f "$f" ] || continue
      if [ -z "$FOUND_WORKSPACE" ] || [ "$(stat -c%s "$f" 2>/dev/null || echo 0)" -gt "$(stat -c%s "$FOUND_WORKSPACE" 2>/dev/null || echo 0)" ]; then
        FOUND_WORKSPACE="$f"
      fi
    done < <(find "$p" -maxdepth 2 -type f \( -iname 'grok-workspace*.zip' -o -iname 'grok-workspace.zip' \) 2>/dev/null | head -20)

    while IFS= read -r f; do
      [ -f "$f" ] || continue
      FOUND_OMEGA="$f"
    done < <(find "$p" -maxdepth 2 -type f -iname '*LEGION_OMEGA*.zip' 2>/dev/null | head -5)

    while IFS= read -r f; do
      [ -f "$f" ] || continue
      FOUND_HTML="$f"
    done < <(find "$p" -maxdepth 3 -type f \( -iname 'RISK_ZERO_DAY_V1.2_GFX.html' -o -iname '*ZERODAY*APOCALYPSE*.html' -o -iname 'LEGION_FUSION*.html' \) 2>/dev/null | head -8)

    while IFS= read -r f; do
      [ -f "$f" ] || continue
      FOUND_MAESTRO_ZIP="$f"
    done < <(find "$p" -maxdepth 2 -type f -iname '*LEGION_MAESTRO*.zip' 2>/dev/null | head -3)
  done

  for d in \
    "$SDCARD/RISK_ZERO_DAY_LEGION_OMEGA" \
    "$HOME_DIR/RISK_ZERO_DAY_LEGION_OMEGA" \
    "$SDCARD/RISK_ZERO_DAY_JUEGO" \
    "$HOME_DIR/RISK_ZERO_DAY" \
    "$HOME_DIR/DIA_ZERO_RISK" \
    "$HOME_DIR/RISK_ZERODAY_CANON"
  do
    [ -d "$d" ] && ok "Carpeta donante/base: $d"
  done

  [ -n "$FOUND_WORKSPACE" ] && ok "Base ZIP: $FOUND_WORKSPACE ($(du -h "$FOUND_WORKSPACE" 2>/dev/null | cut -f1))"
  [ -n "$FOUND_OMEGA" ] && ok "Omega ZIP: $FOUND_OMEGA"
  [ -n "$FOUND_HTML" ] && ok "HTML suelto: $FOUND_HTML"
  [ -n "$FOUND_MAESTRO_ZIP" ] && ok "Maestro ZIP: $FOUND_MAESTRO_ZIP"
}

# ── 4. Instalar / anclar base (copia segura) ──
install_base() {
  mkdir -p "$WORK"
  if [ -f "$WORK/package.json" ] && [ -d "$WORK/src/lib/zeroday" ]; then
    ok "Base canónica ya en $WORK"
    return 0
  fi

  if [ -z "${FOUND_WORKSPACE:-}" ]; then
    warn "No hay grok-workspace.zip — modo HTML/fallback"
    return 1
  fi

  info "Copiando ZIP a respaldo (no se borra el original)..."
  cp -n "$FOUND_WORKSPACE" "$BACKUP_DIR/grok-workspace_$STAMP.zip" 2>/dev/null || \
    cp "$FOUND_WORKSPACE" "$BACKUP_DIR/grok-workspace_$STAMP.zip"

  info "Extrayendo a $WORK (si no existe package.json)..."
  if [ ! -f "$WORK/package.json" ]; then
    unzip -q -o "$FOUND_WORKSPACE" -d "$WORK" 2>/dev/null || {
      TMPU="$HOME_DIR/tmp_legion_extract_$STAMP"
      mkdir -p "$TMPU"
      unzip -q -o "$FOUND_WORKSPACE" -d "$TMPU"
      if [ -f "$TMPU/package.json" ]; then
        cp -a "$TMPU"/. "$WORK"/
      else
        inner=$(find "$TMPU" -maxdepth 2 -name package.json 2>/dev/null | head -1)
        if [ -n "$inner" ]; then
          cp -a "$(dirname "$inner")"/. "$WORK"/
        else
          err "ZIP sin package.json reconocible"
          rm -rf "$TMPU"
          return 1
        fi
      fi
      rm -rf "$TMPU"
    }
  fi
  ok "Base anclada en $WORK"
}

# ── 5. Absorber HTML jugable (solo copia, NUNCA borra origen) ──
absorb_playable() {
  local dest="$WORK/playable"
  mkdir -p "$dest"

  for src in \
    "$SDCARD/RISK_ZERO_DAY_LEGION_OMEGA/jugar" \
    "$HOME_DIR/RISK_ZERO_DAY_LEGION_OMEGA/jugar" \
    "$SDCARD/RISK_ZERO_DAY_JUEGO" \
    "$HOME_DIR/RISK_ZERO_DAY_LEGION_OMEGA/jugar"
  do
    if [ -d "$src" ]; then
      info "Absorbiendo HTML desde $src"
      cp -n "$src"/*.html "$dest/" 2>/dev/null || cp "$src"/*.html "$dest/" 2>/dev/null || true
    fi
  done

  for f in \
    "$SDCARD"/RISK_ZERO_DAY_V1.2_GFX.html \
    "$SDCARD"/RISK_ZERODAY_APOCALYPSE.html \
    "$SDCARD"/RISK_ZERODAY_APOCALYPSE-1.html \
    "$SDCARD"/LEGION_FUSION*.html \
    "$HOME_DIR"/LEGION_FUSION*.html
  do
    for g in $f; do
      [ -f "$g" ] && cp -n "$g" "$dest/" 2>/dev/null || true
    done
  done

  if [ -n "${FOUND_OMEGA:-}" ] && [ ! -d "$SDCARD/RISK_ZERO_DAY_LEGION_OMEGA" ]; then
    local otmp="$HOME_DIR/tmp_omega_$STAMP"
    mkdir -p "$otmp"
    unzip -q -o "$FOUND_OMEGA" -d "$otmp" 2>/dev/null || true
    find "$otmp" -name '*.html' -exec cp -n {} "$dest/" \; 2>/dev/null || true
    rm -rf "$otmp"
  fi

  # index de arranque (no pisa si ya hay index custom)
  if [ ! -f "$dest/index.html" ]; then
    local best=""
    for cand in \
      "$dest/RISK_ZERO_DAY_V1.2_GFX.html" \
      "$dest/VOIDCROWN_MASTER.html" \
      "$dest/VOIDCROWN.html" \
      "$dest/RISK_ZERO_DAY_MASTER_FINAL.html" \
      "$dest/LEGION_FUSION_v2.html"
    do
      [ -f "$cand" ] && best="$cand" && break
    done
    if [ -n "$best" ]; then
      cp "$best" "$dest/index.html"
      ok "index.html → $(basename "$best")"
    fi
  fi

  local n
  n=$(ls "$dest"/*.html 2>/dev/null | wc -l | tr -d ' ')
  ok "HTML absorbidos en $dest ($n archivos)"

  # generar JUGAR.sh local (mejora; no quita el flujo anterior)
  cat > "$WORK/JUGAR.sh" << EOF
#!/data/data/com.termux/files/usr/bin/bash
cd "$dest"
echo "LEGION · http://127.0.0.1:$PORT"
echo "NO Ctrl+C hasta terminar"
command -v termux-open-url >/dev/null && (sleep 1; termux-open-url "http://127.0.0.1:$PORT/") &
exec python3 -m http.server $PORT 2>/dev/null || exec python -m http.server $PORT
EOF
  chmod +x "$WORK/JUGAR.sh" 2>/dev/null || true
  ok "Generado $WORK/JUGAR.sh"
}

# ── 5b. Puerto libre (NUEVO) ──
port_busy() {
  if command -v ss >/dev/null 2>&1; then
    ss -ltn 2>/dev/null | grep -q ":$PORT " && return 0
  fi
  if [ -f "$PIDFILE" ]; then
    local old
    old=$(cat "$PIDFILE" 2>/dev/null || true)
    if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then
      return 0
    fi
  fi
  return 1
}

pick_port() {
  if port_busy; then
    warn "Puerto $PORT ocupado — probando +1"
    PORT=$((PORT + 1))
    PIDFILE="$HOME_DIR/.legion_http_${PORT}.pid"
    LOGFILE="$HOME_DIR/.legion_http_${PORT}.log"
    if port_busy; then
      PORT=$((PORT + 1))
      PIDFILE="$HOME_DIR/.legion_http_${PORT}.pid"
      LOGFILE="$HOME_DIR/.legion_http_${PORT}.log"
    fi
  fi
  ok "Puerto HTTP: $PORT"
}

# ── 5c. Servidor en segundo plano (NUEVO — evita matar con Ctrl+C) ──
serve_background() {
  local dir="$1"
  pick_port
  if port_busy; then
    warn "Ya hay servidor — http://127.0.0.1:$PORT"
    if command -v termux-open-url >/dev/null 2>&1; then
      termux-open-url "http://127.0.0.1:$PORT/"
    fi
    return 0
  fi
  command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock 2>/dev/null || true
  (
    cd "$dir"
    if command -v python3 >/dev/null 2>&1; then
      python3 -m http.server "$PORT"
    else
      python -m http.server "$PORT"
    fi
  ) >"$LOGFILE" 2>&1 &
  echo $! > "$PIDFILE"
  sleep 1
  if kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    ok "Servidor en segundo plano PID $(cat "$PIDFILE")"
    echo
    echo -e "${G}╔══════════════════════════════════════════╗${N}"
    echo -e "${G}║  http://127.0.0.1:$PORT                    ║${N}"
    echo -e "${G}║  Para parar: bash $0 stop                 ║${N}"
    echo -e "${G}╚══════════════════════════════════════════╝${N}"
    echo
    if command -v termux-open-url >/dev/null 2>&1; then
      termux-open-url "http://127.0.0.1:$PORT/"
    fi
  else
    err "No arrancó el servidor — ver $LOGFILE"
    return 1
  fi
}

stop_server() {
  if [ -f "$PIDFILE" ]; then
    local p
    p=$(cat "$PIDFILE" 2>/dev/null || true)
    if [ -n "$p" ] && kill -0 "$p" 2>/dev/null; then
      kill "$p" 2>/dev/null || true
      ok "Servidor $p detenido"
    fi
    rm -f "$PIDFILE"
  else
    warn "No hay PIDFILE — nada que parar"
  fi
  command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock 2>/dev/null || true
}

# ── 6. Lanzar juego (flujo original conservado + mejoras) ──
launch_node() {
  local play="$WORK/playable"
  local html=""

  for cand in \
    "$play/index.html" \
    "$play/RISK_ZERO_DAY_V1.2_GFX.html" \
    "$play/VOIDCROWN_MASTER.html" \
    "$play/VOIDCROWN.html" \
    "$play/RISK_ZERO_DAY_MASTER_FINAL.html" \
    "$play/LEGION_FUSION_v2.html" \
    "$play/RISK_ZERODAY_APOCALYPSE.html"
  do
    [ -f "$cand" ] && html="$cand" && break
  done

  [ -z "$html" ] && [ -f "$WORK/dist/index.html" ] && html="$WORK/dist/index.html"

  if [ -n "$html" ]; then
    local dir
    dir=$(dirname "$html")
    info "Sirviendo desde: $dir ($(basename "$html"))"
    # mejora: fondo por defecto si LEGION_BG=1 o argumento servir
    if [ "${LEGION_BG:-0}" = "1" ]; then
      serve_background "$dir"
      return
    fi
    pick_port
    echo
    echo -e "${G}╔══════════════════════════════════════════╗${N}"
    echo -e "${G}║  RISK ZERODAY · http://127.0.0.1:$PORT     ║${N}"
    echo -e "${G}║  NO pulses Ctrl+C hasta terminar         ║${N}"
    echo -e "${G}║  (o usa: bash $0 servir  → segundo plano)║${N}"
    echo -e "${G}╚══════════════════════════════════════════╝${N}"
    echo
    echo "  http://127.0.0.1:$PORT/$(basename "$html")"
    echo

    if command -v termux-open-url >/dev/null 2>&1; then
      ( sleep 1; termux-open-url "http://127.0.0.1:$PORT/$(basename "$html")" ) &
    elif command -v termux-open >/dev/null 2>&1; then
      ( sleep 1; termux-open "$html" ) &
    fi

    command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock 2>/dev/null || true
    cd "$dir"
    if command -v python3 >/dev/null 2>&1; then
      exec python3 -m http.server "$PORT"
    elif command -v python >/dev/null 2>&1; then
      exec python -m http.server "$PORT"
    else
      err "No hay python. Abre a mano:"
      echo "  termux-open \"$html\""
      exit 1
    fi
  fi

  if [ -f "$WORK/package.json" ] && command -v npm >/dev/null 2>&1; then
    info "Modo npm dev (base TypeScript)..."
    cd "$WORK"
    if [ ! -d node_modules ]; then
      warn "Instalando dependencias (primera vez, puede tardar)..."
      npm install --prefer-offline --no-audit --no-fund 2>/dev/null || npm install
    fi
    echo -e "${G}Dev server — deja esta sesión abierta${N}"
    npm run dev -- --host 0.0.0.0 --port "$PORT" 2>/dev/null || npm run dev
    return
  fi

  err "No hay HTML jugable ni npm. Coloca grok-workspace.zip o Omega en Download."
  exit 1
}

# ── 7. Solo abrir sin servidor (conservado) ──
open_direct() {
  local play="$WORK/playable"
  for cand in \
    "$play/RISK_ZERO_DAY_V1.2_GFX.html" \
    "$play/index.html" \
    "$SDCARD/RISK_ZERO_DAY_V1.2_GFX.html" \
    "$SDCARD/RISK_ZERO_DAY_LEGION_OMEGA/jugar/RISK_ZERO_DAY_V1.2_GFX.html" \
    "$HOME_DIR/RISK_ZERO_DAY_LEGION_OMEGA/jugar/RISK_ZERO_DAY_V1.2_GFX.html" \
    "$SDCARD/RISK_ZERO_DAY_JUEGO/VOIDCROWN.html"
  do
    if [ -f "$cand" ]; then
      ok "Abriendo directo: $cand"
      if command -v termux-open >/dev/null 2>&1; then
        termux-open "$cand"
      elif command -v termux-open-url >/dev/null 2>&1; then
        termux-open-url "file://$cand"
      else
        echo "Abre en el navegador de archivos: $cand"
      fi
      return 0
    fi
  done
  err "No se encontró HTML para abrir directo"
  return 1
}

# ── 8. Reporte (ampliado, no quita campos viejos) ──
write_report() {
  local rep="$REPORT_DIR/legion_maestro_$STAMP.txt"
  {
    echo "LEGION MAESTRO ÚNICO $VERSION"
    echo "stamp=$STAMP env=${ENV:-unknown}"
    echo "work=$WORK"
    echo "workspace_zip=${FOUND_WORKSPACE:-none}"
    echo "omega_zip=${FOUND_OMEGA:-none}"
    echo "html=${FOUND_HTML:-none}"
    echo "port=$PORT"
    echo "pidfile=$PIDFILE"
    echo "--- playable ---"
    ls -la "$WORK/playable" 2>/dev/null || true
    echo "--- protocol ---"
    ls -d "$HOME_DIR/legion-core" "$HOME_DIR/reportes" 2>/dev/null || true
  } > "$rep" 2>/dev/null || true
  info "Reporte: $rep"
}

# ── 9. Instalar script en home + Download (NUEVO) ──
self_install() {
  local me="$0"
  if [ -f "$me" ]; then
    cp -n "$me" "$HOME_DIR/LEGION_MAESTRO_UNICO.sh" 2>/dev/null || cp "$me" "$HOME_DIR/LEGION_MAESTRO_UNICO.sh"
    chmod +x "$HOME_DIR/LEGION_MAESTRO_UNICO.sh" 2>/dev/null || true
    if [ -d "$SDCARD" ]; then
      cp -n "$me" "$SDCARD/LEGION_MAESTRO_UNICO.sh" 2>/dev/null || cp "$me" "$SDCARD/LEGION_MAESTRO_UNICO.sh" 2>/dev/null || true
    fi
    ok "Script disponible en ~/LEGION_MAESTRO_UNICO.sh"
  fi
}

# ── menú (opciones viejas + nuevas) ──
menu() {
  echo "  1) INSTALAR + ABSORBER + JUGAR (servidor primer plano)"
  echo "  2) Solo JUGAR (servidor, si ya instaló)"
  echo "  3) Abrir HTML directo (sin servidor)"
  echo "  4) Solo buscar / diagnosticar"
  echo "  5) Servir en SEGUNDO PLANO (no se muere con Ctrl+C)"
  echo "  6) Checkpoint (foto del estado, no borra nada)"
  echo "  7) Detener servidor en segundo plano"
  echo "  8) Salir"
  echo
  printf "Elige [1-8] (default 5): "
  read -r choice || true
  choice=${choice:-5}
  case "$choice" in
    1) protocol_check; checkpoint; find_zips; install_base || true; absorb_playable; write_report; self_install; launch_node ;;
    2) find_zips; absorb_playable; launch_node ;;
    3) find_zips; absorb_playable; open_direct ;;
    4) protocol_check; find_zips; write_report; ok "Diagnóstico listo" ;;
    5) protocol_check; find_zips; install_base || true; absorb_playable; write_report
       LEGION_BG=1 launch_node ;;
    6) protocol_check; find_zips; checkpoint; write_report ;;
    7) stop_server ;;
    8) exit 0 ;;
    *) warn "Opción inválida"; menu ;;
  esac
}

# ── main ──
banner
detect_env

case "${1:-}" in
  play|jugar)
    protocol_check; checkpoint; find_zips; install_base || true; absorb_playable; write_report; self_install; launch_node
    ;;
  direct|directo)
    find_zips; absorb_playable; open_direct
    ;;
  diag|diagnostico)
    protocol_check; find_zips; write_report
    ;;
  servir|bg|background)
    protocol_check; find_zips; install_base || true; absorb_playable; write_report
    LEGION_BG=1 launch_node
    ;;
  stop|parar)
    stop_server
    ;;
  checkpoint|ckpt)
    protocol_check; find_zips; checkpoint; write_report
    ;;
  install-self)
    self_install
    ;;
  *)
    menu
    ;;
esac
