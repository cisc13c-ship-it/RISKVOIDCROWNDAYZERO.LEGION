#!/data/data/com.termux/files/usr/bin/bash
HERE="$(cd "$(dirname "$0")" && pwd)"
PORT="${PORT:-8001}"
cd "$HERE/jugar"
echo "http://127.0.0.1:$PORT/RISK_VOID_KAOS_THEATER.html"
command -v termux-open-url >/dev/null 2>&1 && (sleep 1; termux-open-url "http://127.0.0.1:$PORT/RISK_VOID_KAOS_THEATER.html") &
exec python3 -m http.server "$PORT" 2>/dev/null || exec python -m http.server "$PORT"
